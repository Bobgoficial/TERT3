var Agente=navigator.userAgent.toUpperCase();
if(1+Agente.indexOf('MSIE') || 1+Agente.indexOf('TRIDENT'))var sBrowser='IE';
else if(1+Agente.indexOf('MZ605'))var sBrowser='XO';
else if(1+Agente.indexOf('FIREFOX'))var sBrowser='FF';
else if(1+Agente.indexOf('CHROME'))var sBrowser='CH';
else if(1+Agente.indexOf('SAFARI') && 1+Agente.indexOf('IPAD'))var sBrowser='SAIPAD';
else if(1+Agente.indexOf('SAFARI') && 1+Agente.indexOf('IPHONE'))var sBrowser='SAIPHONE';
else if(1+Agente.indexOf('SAFARI'))var sBrowser='SA';
else if(1+Agente.indexOf('OPERA'))var sBrowser='OP';
else var sBrowser='NS';

var IDCategoriaAtualFC=0;
var IDCategoriaNivel0FC=0;

var ImgLoadingFC="/images/loading.gif?cccfc=1";
ImgOnError="/images/nd";
CodeOnNoObject="";
var OffsetAutoPagFC=0,TimeToAutoPagFC=0,iPagProdFC=0,iPagCountFC=0;
var iTimerChatZ=15000;

var FCLib$=(function(){
  var TipoRWDBootstrap=3;
  var TipoRWDFoundation=4;
  var TipoRWDPlugins=5;
  var TipoRWDVex=6;
  var oFoundationJSON={};
  var bExistDivAlertRWD=false;
  var oAlertFocus=null;
  var oFieldFocus=null;
  var ofnAlertClosed=null;
  var wHandler=null;
  var pQuery=null;
  var oCatMenu=null;
  var oDescriptor1Menu=null;
  var oDescriptor2Menu=null;
  var oDescriptor3Menu=null;
  var IsOldIE=(sBrowser=='IE' && (Agente.indexOf('MSIE 6')>=0 || Agente.indexOf('MSIE 7')>=0 || Agente.indexOf('MSIE 8')>=0));
  var oWaveImg={};
  var aBuyTogether=[];
  var GlobalSigninUser={};
  var isGoogleInit=false;
  var oBtnLoginGoogle=null;
  var oSystemURLs={
    "url-prod":["/listaprodutos.asp","/product-list.ehc"],
    "url-register":["/cadastro.asp","/register.ehc"],
    "url-add-product":["/addproduto.asp","/add-product.ehc"],
    "url-add-multiple-products":["/addmult.asp","/add-multiple.ehc"],
    "url-help":["/ajuda.asp","/help.ehc"],
    "url-advanced-search":["/buscaavancada.asp","/advanced-search.ehc"],
    "url-contact":["/faleconosco.asp","/contact.ehc"],
    "url-store-suggest":["/indique.asp","/store-suggest.ehc"],
    "url-product-availability":["/avisadispproduto.asp?idproduto=","/product-availability.ehc?productid="],
    "url-product-recommend":["/indiqueproduto.asp?idproduto=","/product-recommend.ehc?productid="],
    "url-product-review":["/opiniao.asp?idproduto=","/product-review.ehc?productid="],
    "url-checkout":["/checkout.asp","/checkout.ehc"],
    "url-account":["/account.asp","/account.ehc"],
    "url-newsletter":["/newsletter.asp","/newsletter.ehc"],
    "url-recalculate":["/recalcula.asp","/recalculate.ehc"],
    "url-track":["/track.asp","/track.ehc"],
    "url-wishlist":["/wishlist.asp","/wishlist.ehc"],
    "url-categories":["/categorias.asp","/categories.ehc"],
    "url-home":["/home.asp","/home.ehc"],
    "url-custom":["/custom.asp","/custom.ehc"],
    "url-news":["/noticias.asp","/news.ehc"],
    "url-purchase-list":["/lista-de-compra","/purchase-list"],
    "url-highlights":["/page,arq,destaques.htm","/page,file,highlights.htm"],
    "url-sale":["/prod,promocao,1,ofertas.htm","/prod,offers,1,offers.htm"],
    "url-release":["/prod,lancamento,1,novidades.htm","/prod,releases,1,releases.htm"],
    "url-cart-list":["/cartlist.asp","/cart-list.ehc"],
    "url-product-info":["/infoprod.asp","/product-info.ehc"],
    "url-delete-from-safe":["/exccofre.asp","/delete-from-safe.ehc"],
    "url-popup-iframe":["/popupif.asp","/popup-iframe.ehc"],
    "url-google-analytics":["/googleanalytics.asp","/google-analytics.ehc"],
    "url-global-signin":["/globalsignin.asp","/global-signin.ehc"],
    "url-json-wishlist":["/jsonwishlist.asp","/json-wishlist.ehc"],
    "url-xml-cart":["/xmlcart.asp","/xmlcart.ehc"],
    "url-xml-page-history":["/xmlpagehistory.asp","/xml-page-history.ehc"],
    "url-xml-shipping-cep":["/xmlshippingcep.asp","/xml-shipping-cep.ehc"],
    "url-xml-logout":["/xmllogout.asp","/xmllogout.ehc"]
  };

  function fnUseEHC(){return ((FC$.isEH || FC$.IDLoja>(FC$.isTest?10460:40500))?true:false);}

  function uk(sKey){if(oSystemURLs[sKey])return oSystemURLs[sKey][(fnUseEHC()?1:0)];else console.warn("js var not found in system URLs %c"+ sKey,"color:red");}

  function formatMoney(sValue,sCurrencySymbol){
    return (sValue<0?"-":"")+ sCurrencySymbol +"&nbsp;"+ Math.abs(sValue?sValue:0).toLocaleString(FC$.LanguageCountry,{minimumFractionDigits:2,maximumFractionDigits:2});
  }

  function formatMoneyInt(sValue){
    return parseInt(sValue?sValue:0).toLocaleString(FC$.LanguageCountry,{minimumFractionDigits:0,maximumFractionDigits:0});
  }

  function getDecimalSep(){return (0).toLocaleString(FC$.LanguageCountry,{minimumFractionDigits:1,maximumFractionDigits:1}).substr(1,1);}

  function useLangResource(oResources){
    var aVars=document.getElementsByTagName("var"),iVars=aVars.length,oVar,sKey;
    for(var i=0;i<iVars;i++){
      oVar=aVars[i];
      sKey=oVar.getAttribute("key");
      if(sKey){if(oResources[sKey])oVar.innerHTML=oResources[sKey];else console.warn("html var not found in language resources %c"+ sKey,"color:red");}
    }
  }

  function fnAjaxExecFC(file,sParams,IsPOST,fnCallback,param1,param2,param3){
    sParams=sParams.replace(/ /g,"+");
    var oRet=null;
    if(window.XMLHttpRequest){oRet=new XMLHttpRequest();}
    else if(window.ActiveXObject){oRet=new ActiveXObject("Microsoft.XMLHTTP");} 
    else{return;}
    oRet.onreadystatechange=function(){if(oRet.readyState==4){fnCallback(oRet,param1,param2,param3);}};
    if(IsPOST){
      oRet.open('POST',file,true);
      oRet.setRequestHeader("Content-type","application/x-www-form-urlencoded");
      oRet.send(sParams);
    }
    else{
      oRet.open('GET',file+'?'+sParams,true);
      oRet.send('');
    }
  }

  function loadAsyncCSS(href){
    var ss=document.createElement("link");
    var refs=(document.body||document.getElementsByTagName("head")[0]).childNodes;
    var ref=refs[refs.length-1];
    ss.rel="stylesheet";ss.href=href;ss.media="invalid-media";
    onReady(function(){ref.parentNode.insertBefore(ss,ref.nextSibling);});
    if(ss.addEventListener)ss.addEventListener("load",function(){this.media="all";});
    return ss;
  };

  function GetCookie(name){
    var arg=name+"=";
    var alen=arg.length;
    var clen=document.cookie.length;
    var i=0;
    while(i<clen){
      var j=i+alen;
      if(document.cookie.substring(i,j)==arg)return getCookieVal(j);
      i=document.cookie.indexOf(" ",i)+1;
      if(i==0)break;
    }
    return null;
  }

  var xOffsetScreenLimits=50,yOffsetScreenLimits=50,xMinShiftLazyLoad=50,yMinShiftLazyLoad=50,iMinTimerLazyLoad=500,iMaxTimerLazyLoad=2000,iFadeTimeLazyLoad=500,iFadeStepsLazyLoad=10,iTimerLazyLoad=new Date().getTime(),iBottomLazyLoad=0,iRightLazyLoad=0,LazyLoadWaitImage="/images/loading.gif?cccfc=1";
  function getLimits(obj){
    var oLimits={},oTop=0,oBottom=0,oLeft=0,oRight=0;
    oBottom=obj.offsetHeight;
    oRight=obj.offsetWidth;
    while(obj){
      oTop+=obj.offsetTop;
      oLeft+=obj.offsetLeft;
      obj=obj.offsetParent;
    }
    oBottom+=oTop;
    oRight+=oLeft;
    oLimits.top=oTop;
    oLimits.bottom=oBottom;
    oLimits.left=oLeft;
    oLimits.right=oRight;
    return oLimits;
  }

  function getScreenLimits(){
    var oLimits={},oTop=0,oBottom=0,oLeft=0,oRight=0;
    if(window.pageYOffset)oTop=window.pageYOffset;
    else oTop=Math.max(document.documentElement.scrollTop,document.body.scrollTop);
    if(window.innerHeight)oBottom=oTop+window.innerHeight;
    else oBottom=oTop+Math.max(document.documentElement.clientHeight,document.body.clientHeight);
    if(window.pageXOffset)oLeft=window.pageXOffset;
    else oLeft=Math.max(document.documentElement.scrollLeft,document.body.scrollLeft);
    if(window.innerWidth)oRight=oLeft+window.innerWidth;
    else oRight=oLeft+Math.max(document.documentElement.clientWidth,document.body.clientWidth);
    oLimits.top=oTop-FCLib$.yOffsetScreenLimits;
    oLimits.bottom=oBottom+FCLib$.yOffsetScreenLimits;
    oLimits.left=oLeft-FCLib$.xOffsetScreenLimits;
    oLimits.right=oRight+FCLib$.xOffsetScreenLimits;
    return oLimits;
  }

  function isOnScreen(obj){
    var oLimitsObj=getLimits(obj);
    var oLimitsScreen=getScreenLimits();
    return ((oLimitsObj.top<=oLimitsScreen.top && oLimitsObj.bottom>=oLimitsScreen.top) || (oLimitsObj.top>=oLimitsScreen.top && oLimitsObj.top<=oLimitsScreen.bottom)) &&
           ((oLimitsObj.left<=oLimitsScreen.left && oLimitsObj.right>=oLimitsScreen.left) || (oLimitsObj.left>=oLimitsScreen.left && oLimitsObj.left<=oLimitsScreen.right));
  }

  function initLazyLoad(){
    if(!IsOldIE){
      var style=document.createElement("style");
      style.type="text/css";
      style.innerHTML="img[data-src*='/lojas/'][src='/images/loading.gif?cccfc=1']{max-width:16px!important;max-height:11px!important;}";
      document.getElementsByTagName("head")[0].appendChild(style);
    }
    iBottomLazyLoad=getScreenLimits().bottom;
    iRightLazyLoad=getScreenLimits().right;
    FCLib$.AddEvent(document,"scroll",execLazyLoadEvents);
    FCLib$.AddEvent(window,"resize",execLazyLoadEvents);
    setInterval(function(){execLazyLoad();},FCLib$.iMaxTimerLazyLoad);
    execLazyLoad();
  }

  function execLazyLoadEvents(){
    var isMinShift=(Math.abs(iBottomLazyLoad-getScreenLimits().bottom)>FCLib$.yMinShiftLazyLoad || Math.abs(iRightLazyLoad-getScreenLimits().right)>FCLib$.xMinShiftLazyLoad);
    if(isMinShift){
      iBottomLazyLoad=getScreenLimits().bottom;
      iRightLazyLoad=getScreenLimits().right;
    }
    var isScrollTimer=(new Date().getTime()-iTimerLazyLoad>FCLib$.iMinTimerLazyLoad);
    if(isScrollTimer){
      iTimerLazyLoad=new Date().getTime();
    }
    if(isMinShift || isScrollTimer)execLazyLoad();
  }

  function execLazyLoad(){
    var sDataSrc;
    var aImg=document.getElementsByTagName("img");
    var iTamImg=aImg.length;
    for(var i=0;i<iTamImg;i++){
      sDataSrc=aImg[i].getAttribute("data-src");
      if(sDataSrc && sDataSrc!=""){
        if(isOnScreen(aImg[i])){
          if(FCLib$.iFadeTimeLazyLoad>0 && !IsOldIE){
            aImg[i].style.opacity=0;
            AddEvent(aImg[i],"load",fadeIn(aImg[i],FCLib$.iFadeTimeLazyLoad,FCLib$.iFadeStepsLazyLoad));
          }
          aImg[i].src=sDataSrc;
          aImg[i].removeAttribute("data-src");
        }
        else{
          if(aImg[i].src=="")aImg[i].src=FCLib$.LazyLoadWaitImage;
        }
      }
    }
  }

  function fadeIn(oID,iFadeTime,iSteps,oInt){
    if(oInt==undefined){
      if(iFadeTime==undefined)iFadeTime=500;
      if(iSteps==undefined)iSteps=10;
      oInt=setInterval(function(){fadeIn(oID,iFadeTime,iSteps,oInt);},iFadeTime/iSteps);
    }
    else{
      if(oID.style.opacity=="")oID.style.opacity=1/iSteps;
      else oID.style.opacity=parseFloat(oID.style.opacity)+(1/iSteps);
      if(oID.style.opacity>=1)clearInterval(oInt);
    }
  }

  function execWaveInterchange(){
    var i,j,sDataSrc,oDataSrc,aOption,aSrcQuery,mql,sSrc,sQuery,bNewQuery,bDisableLazyLoad,
      bSupportMatchMedia=(window.matchMedia!=undefined && document.addEventListener!=undefined),
      bLazyLoad=(FC$.LazyLoad>0),
      aQueries=new Array(),
      oRegOption=/([^\[])+(?=[\w\W])(?![^\]])/g,
      oRegSrcQuery=/^[^\,]{1,}\b|\([\s\S]+\)/g,
      oFn=function(mediaQueryList){fnWaveOnQuery(mediaQueryList);},
      aImg=document.getElementsByTagName("img");
    var iTamImg=aImg.length;
    for(i=0;i<iTamImg;i++){
      sDataSrc=aImg[i].getAttribute("wave-interchange");
      if(sDataSrc && sDataSrc!=""){
        if(bSupportMatchMedia){
          aOption=sDataSrc.match(oRegOption);
          if(aOption){
            for(j=0;j<aOption.length;j++){
              aSrcQuery=aOption[j].match(oRegSrcQuery);
              if(aSrcQuery){
                if(aSrcQuery.length==2){
                  sSrc=aSrcQuery[0];
                  sQuery=aSrcQuery[1];
                  mql=window.matchMedia(sQuery);
                  sQuery=mql.media;
                  bNewQuery=(oWaveImg[sQuery+"oImg"]==undefined);
                  if(bNewQuery){
                    oWaveImg[sQuery+"oImg"]=new Array();
                    oWaveImg[sQuery+"sSrc"]=new Array();
                    aQueries[aQueries.length]=sQuery;
                    mql.addListener(oFn);
                  }
                  oWaveImg[sQuery+"oImg"][oWaveImg[sQuery+"oImg"].length]=aImg[i];
                  oWaveImg[sQuery+"sSrc"][oWaveImg[sQuery+"sSrc"].length]=sSrc;
                }
              }
            }
          }
       }
       else{
         sDataSrc=aImg[i].getAttribute("fallback-src");
         if(sDataSrc && sDataSrc!=""){
           bDisableLazyLoad=(aImg[i].getAttribute("disablelazyload")!=null);
           if(bLazyLoad && !bDisableLazyLoad && !isOnScreen(aImg[i]))aImg[i].setAttribute("data-src",sDataSrc);
           else aImg[i].src=sDataSrc;
         }
       }
       aImg[i].removeAttribute("fallback-src");
       aImg[i].removeAttribute("wave-interchange");
      }
    }
    for(i=0;i<aQueries.length;i++){
      mql=window.matchMedia(aQueries[i]);
      oFn(mql);
    }
  }
  
  function fnWaveOnQuery(mediaQueryList){
    var oImg,sSrc,bDisableLazyLoad,bLazyLoad=(FC$.LazyLoad>0);
    if(mediaQueryList.matches){
      var sMedia=mediaQueryList.media;
      for(var i=0;i<oWaveImg[sMedia+"oImg"].length;i++){
        oImg=oWaveImg[sMedia+"oImg"][i];
        sSrc=oWaveImg[sMedia+"sSrc"][i];
        if(sSrc.toLowerCase()=="none")oImg.removeAttribute("src");
        else{
          bDisableLazyLoad=(oImg.getAttribute("disablelazyload")!=null);
          if(bLazyLoad && !bDisableLazyLoad && !isOnScreen(oImg))oImg.setAttribute("data-src",sSrc);
          else oImg.src=sSrc;
        }
      }
    }
  }

  function getCookieVal(offset){
    var endstr=document.cookie.indexOf(";",offset);
    if(endstr==-1)endstr=document.cookie.length;
    return unescape(document.cookie.substring(offset,endstr));
  }
  
  function SetCookie(name,value){
    var argv=SetCookie.arguments;
    var argc=SetCookie.arguments.length;
    var expires=(argc>2)?argv[2]:null;
    var path=(argc>3)?argv[3]:null;
    var domain=(argc>4)?argv[4]:null;
    var secure=(argc>5)?argv[5]:false;
    document.cookie=name+"="+escape(value)+((expires==null)?"":(";expires=" + expires.toGMTString()))+((path==null)?"":(";path="+path))+((domain==null)?"":(";domain="+domain))+((secure==true)?"; secure":"");
  }

  function AddEvent(target,eventType,eventHandler){
    if(target.addEventListener)target.addEventListener(eventType,eventHandler,false);
    else if(target.attachEvent)target.attachEvent("on"+eventType,eventHandler);
  }
  
  function RemoveEvent(target,eventType,eventHandler){
    if(target.removeEventListener)target.removeEventListener(eventType,eventHandler,false);
    else if(target.detachEvent)target.detachEvent("on"+eventType,eventHandler);
  }

  function onReady(eventHandler){
    if(IsOldIE)setTimeout(function(){eventHandler();},1);
    else AddEvent(document,"DOMContentLoaded",eventHandler);
  }

  function onLoaded(eventHandler){
    if(document.readyState=="complete")eventHandler();
    else AddEvent(window,"load",eventHandler);
  }

  function AlertRWD(sAlertMsg){
    var sMsg=sAlertMsg.replace(/\n/g,'<br>');
    ofnAlertClosed=null;
    if(FC$.TypeRWD==TipoRWDBootstrap){
      if(!bExistDivAlertRWD){
        var oDiv=document.createElement('div');
        oDiv.id='idAlertRWD';
        document.body.appendChild(oDiv);
        oDiv.innerHTML="<div class='modal fade' id='idAlertFC' tabindex='-1' role='dialog' aria-hidden='true'><div class='modal-dialog modal-sm'><div class='modal-content'><div class='modal-body'><button type='button' class='close' data-dismiss='modal' aria-hidden='true'>&times;</button><div id='idAlertMsgFC'></div></div></div></div></div>";
        bExistDivAlertRWD=true;
      }
      $('#idAlertMsgFC').html(sMsg);
      $('#idAlertFC').on('hidden.bs.modal',function(){AlertClosed();});
      $('#idAlertFC').modal();
      oAlertFocus=null;
    }
    else if(FC$.TypeRWD==TipoRWDFoundation){
      if(!bExistDivAlertRWD){
        var oDiv=document.createElement('div');
        oDiv.id='idAlertRWD';
        document.body.appendChild(oDiv);
        oDiv.innerHTML="<div id='idAlertFC' class='reveal-modal medium' data-reveal><h4 id='idAlertMsgFC'></h4><a id='idCrossFC' class='close-reveal-modal'>&#215;</a></div>";
        $(document).foundation(FCLib$.oFoundationJSON);
        bExistDivAlertRWD=true;
      }
      $('#idAlertMsgFC').html(sMsg);
      $('#idAlertFC').foundation('reveal','open');
      oAlertFocus=null;
      $(document).on('closed.fndtn.reveal','[data-reveal]',function(){AlertClosed();});
    }
    else if(FC$.TypeRWD==TipoRWDPlugins){
      vex.dialog.alert({message:sMsg,callback:function(){AlertClosed()}});
      oAlertFocus=document.activeElement;
    }
    else if(FC$.TypeRWD==TipoRWDVex){
      vex.defaultOptions.closeAllOnPopState=false;
      vex.dialog.alert({unsafeMessage:sMsg,afterClose:function(){vex.defaultOptions.closeAllOnPopState=true;},callback:function(){AlertClosed()}});
      oAlertFocus=document.activeElement;
    }
    setTimeout(function(){oFieldFocus=document.activeElement;if(oAlertFocus)oAlertFocus.focus();else if(oFieldFocus)oFieldFocus.blur();},100);
  }

  function AlertClosed(){
    if(oFieldFocus)oFieldFocus.focus();if(FCLib$.ofnAlertClosed)FCLib$.ofnAlertClosed();
  }
  
  function OpenRWD(URL,wName,wFeat){
    "use strict";
    var oLimits=getScreenLimits();
    var iScreenWidth=oLimits.right-oLimits.left;
    var iScreenHeight=oLimits.bottom-oLimits.top;
    if(typeof wName!="undefined"){
      var aPar,oContentCSS={};
      var aFeat=wFeat.split(",");
      for(var i=0;i<aFeat.length;i++){
        aPar=aFeat[i].split("=");
        if(aPar.length==2){
          if(!isNaN(aPar[1])){
            aPar[0]=aPar[0].toLowerCase();
            aPar[1]=parseInt(aPar[1]);
            if(aPar[0]=="width"){if(aPar[1]>iScreenWidth*.9)aPar[1]="90%";else aPar[1]+=40;}
            if(aPar[0]=="height"){if(aPar[1]>iScreenHeight*.7)aPar[1]=Math.round(iScreenHeight*.7);else aPar[1]+=60;}
          }
          oContentCSS[aPar[0]]=aPar[1]+(isNaN(aPar[1])?"":"px");
        }
      }
    }
    else{
      var oContentCSS={width:"90%",height:Math.round(iScreenHeight*.7) +"px"};
    }
    if(FC$.TypeRWD==TipoRWDVex){
      vex.defaultOptions.closeAllOnPopState=false;
      FCLib$.wHandler=vex.open({
        unsafeContent:"<iframe"+ (typeof wName!="undefined"?" id='"+wName+"'":"") +" style='padding-top:20px;width:100%;height:100%' src='"+ URL +"'></iframe>",
        afterClose:function(){vex.defaultOptions.closeAllOnPopState=true;},
        contentClassName:newClass(oContentCSS)
      });
    }
    else{
      FCLib$.wHandler=vex.open({
        content:"<iframe"+ (typeof wName!="undefined"?" id='"+wName+"'":"") +" style='padding-top:20px;width:100%;height:100%' src='"+ URL +"'></iframe>",
        contentCSS:oContentCSS
      });
    }
    return FCLib$.wHandler;
  }

  function SelfCloseRWD(){
    if(FC$.TypeRWD==TipoRWDVex)window.parent.vex.close(window.parent.FCLib$.wHandler);
    else window.parent.vex.close(window.parent.FCLib$.wHandler.data().vex.id);
  }

  function newClass(oContentCSS){
    var sClass="rndClass",
     sCSS=JSON.stringify(oContentCSS).replace(/,/g,"!important;").replace(/\"/g,"");
    for(var i=0;i<10;i++)sClass+=getRandomChar();
    var oStyle=document.createElement("style");
    oStyle.innerHTML="."+ sClass + sCSS;
    document.head.appendChild(oStyle);
    return sClass;
  }

  function AppendGA(IDLoja,sPage,IsTeste){
    if(IsTeste)sCode="G-7BHWXBMPP6";
    else sCode="G-25BB5HTQYT";
    oFrame=document.createElement("IFRAME");
    oFrame.setAttribute("src",uk("url-google-analytics") +"?code="+ sCode +"&storeid="+ IDLoja +"&pag="+ sPage);
    oFrame.style.width="1px";
    oFrame.style.height="1px";
    oFrame.style.display="none";
    document.body.appendChild(oFrame);
  }

  function ShowBadgeFC(IsMin){
    if(FC$.isEH || FC$.Language!=0)ShowBadgeEH(IsMin);
    else{
      if(IsMin)var sURL="https://www.fastcommerce.com.br/?origem=badgetxtfc&utm_source=BadgeTxt+Fastcommerce&utm_medium=Badge&utm_campaign=BadgeTxt+Lojas+Fastcommerce";
      else var sURL="https://www.fastcommerce.com.br/?origem=badgefc&utm_source=Badge+Fastcommerce&utm_medium=Badge&utm_campaign=Badge+Lojas+Fastcommerce";
      var oDiv=document.createElement("div");
      oDiv.id="idBadgeFC";
      if(IsMin)oDiv.innerHTML="<a href='"+ sURL +"' rel='noopener' target='_blank' style='text-decoration:none'><div id='idBadgeAllFC' style='line-height:normal;border:1px solid #6f6f6f;width:70px;position:fixed;bottom:0;right:0;z-index:99999;font-size:8px;font-family:verdana;font-weight:bold;text-align:right'><div id=idBadgeFCl1 style='background-color:#000000;color:#FFFFFF;padding:0 2px 0 0'>Powered by</div><div id=idBadgeFCl2 style='background-color:#EED494;color:#000000;padding:0 2px 0 0'>Fastcommerce</div></div></a>";
      else oDiv.innerHTML="<a href='"+ sURL +"' rel='noopener' target='_blank'><!--[if lte IE 8]><div id='idBadgeAllFC' style='height:auto;position:fixed;bottom:0;right:0;z-index:99999;'><img src='/images/BadgeFC.png?cccfc=1' style='border:0;width:91px;height:31px;'><![endif]--><!--[if gt IE 8]><div id='idBadgeAllFC' style='width:5%;min-width:80px;height:auto;position:fixed;bottom:0;right:0;z-index:99999;'><img src='/images/BadgeFC.svg?cccfc=1' style='border:0;width:100%;height:auto;'><![endif]--><!--[if !IE]> --><div id='idBadgeAllFC' style='width:5%;min-width:80px;height:auto;position:fixed;bottom:0;right:0;z-index:99999;'><img src='/images/BadgeFC.svg?cccfc=1' style='border:0;width:100%;height:auto;'><!-- <![endif]--></div></a>";
      document.body.appendChild(oDiv);
    }
  }

  function ShowBadgeEH(IsMin){
    if(IsMin)var sURL="https://www.ehcommerce.com/?origem=badgetxteh&utm_source=BadgeTxt+ehcommerce&utm_medium=Badge&utm_campaign=BadgeTxt+Stores+ehcommerce";
    else var sURL="https://www.ehcommerce.com/?origem=badgeeh&utm_source=Badge+ehcommerce&utm_medium=Badge&utm_campaign=Badge+Stores+ehcommerce";
    var oDiv=document.createElement("div");
    oDiv.id="idBadgeFC";
    if(IsMin)oDiv.innerHTML="<a href='"+ sURL +"' rel='noopener' target='_blank' style='text-decoration:none'><div id='idBadgeAllFC' style='line-height:normal;border:1px solid #6f6f6f;width:70px;position:fixed;bottom:0;right:0;z-index:99999;font-size:8px;font-family:verdana;font-weight:bold;text-align:right'><div id=idBadgeFCl1 style='background-color:#000000;color:#FFFFFF;padding:0 2px 0 0'>Powered by</div><div id=idBadgeFCl2 style='background-color:#EED494;color:#000000;padding:0 2px 0 0'>ehcommerce</div></div></a>";
    else oDiv.innerHTML="<a href='"+ sURL +"' rel='noopener' target='_blank'><!--[if lte IE 8]><div id='idBadgeAllFC' style='height:auto;position:fixed;bottom:0;right:0;z-index:99999;'><img src='/images/BadgeFC.png?cccfc=1' style='border:0;width:91px;height:31px;'><![endif]--><!--[if gt IE 8]><div id='idBadgeAllFC' style='width:5%;min-width:80px;height:auto;position:fixed;bottom:0;right:0;z-index:99999;'><img src='/images/badgeeh.svg?cccfc=1' style='border:0;width:100%;height:auto;'><![endif]--><!--[if !IE]> --><div id='idBadgeAllFC' style='width:5%;min-width:80px;height:auto;position:fixed;bottom:0;right:0;z-index:99999;'><img src='/images/badgeeh.svg?cccfc=1' style='border:0;width:100%;height:auto;'><!-- <![endif]--></div></a>";
    document.body.appendChild(oDiv);
  }

  function MirrorCartQty(este){
    if(este.name.substring(0,1)=="s")var sPara="q";
    else var sPara="s";
    document.getElementById(sPara + este.name.substring(1)).value=este.value;
  }

  function MirrorCartCupom(este){
    var sDif=este.name.substring(0,1);
    if(sDif=="C"){var sPara1="K";var sPara2="Q";}
    else if(sDif=="K"){var sPara1="C";var sPara2="Q";}
    else if(sDif=="Q"){var sPara1="C";var sPara2="K";}
    document.getElementById(sPara1 + este.name.substring(1)).value=este.value;
    document.getElementById(sPara2 + este.name.substring(1)).value=este.value;
  }

  function FormatPreco(sPreco){
    var sPrecoF=sPreco.replace(/&nbsp;/g," "),iPosInt=sPrecoF.indexOf(" "),iPosDec=sPrecoF.length-3,sMoedaVendas=sPrecoF.substring(0,iPosInt);
    if(isNaN(sPrecoF.charAt(iPosDec)))sPrecoF="<span class='FCPriceInt'>"+ sPrecoF.substring(iPosInt+1,iPosDec) +"</span><span class='FCPriceCent'>"+ sPrecoF.substr(iPosDec,3) +"</span>";
    else sPrecoF=sPrecoF.substring(iPosInt+1,sPrecoF.length);
    sPrecoF="<span class='FCPrice'><span class='FCCurrencyLabel'>"+ sMoedaVendas +"</span> <span class='FCPriceValue'>"+ sPrecoF +"</span></span>";
    return sPrecoF;
  }

  function enlargeQtyInput(){
    if(document.querySelectorAll){
      var aQty=document.querySelectorAll(".FCCartQtyInput");
      for(var i=0;i<aQty.length;i++)aQty[i].maxLength="5";
    }
  }

  function showPwdViewer(){setTimeout(function(){FCLib$.showPwdViewerDelayed();},500);}

  function showPwdViewerDelayed(){
    var sEye="<svg version='1.1' class='pwdEye' style='cursor:pointer;float:left;margin-left:4px;stroke:white;fill-opacity:0.5' onclick='FCLib$.togglePwdView(this)' xmlns='http://www.w3.org/2000/svg' xmlns:xlink='http://www.w3.org/1999/xlink' width='16' height='16' viewBox='0 0 32 32'><path d='M16 6c-6.979 0-13.028 4.064-16 10 2.972 5.936 9.021 10 16 10s13.027-4.064 16-10c-2.972-5.936-9.021-10-16-10zM23.889 11.303c1.88 1.199 3.473 2.805 4.67 4.697-1.197 1.891-2.79 3.498-4.67 4.697-2.362 1.507-5.090 2.303-7.889 2.303s-5.527-0.796-7.889-2.303c-1.88-1.199-3.473-2.805-4.67-4.697 1.197-1.891 2.79-3.498 4.67-4.697 0.122-0.078 0.246-0.154 0.371-0.228-0.311 0.854-0.482 1.776-0.482 2.737 0 4.418 3.582 8 8 8s8-3.582 8-8c0-0.962-0.17-1.883-0.482-2.737 0.124 0.074 0.248 0.15 0.371 0.228zM16 12.813c0 1.657-1.343 3-3 3s-3-1.343-3-3 1.343-3 3-3 3 1.343 3 3z'></path></svg>";
    if(document.querySelectorAll)var aPwd=document.querySelectorAll("input[type='password']");
    else{
      var aPwd=[];var oInputs=document.getElementsByTagName("input");
      for(var i=0;i<oInputs.length;i++)if(oInputs[i].type.toLowerCase()==="password")aPwd.push(oInputs[i]);
    }
    for(var i=0;i<aPwd.length;i++){
      if(aPwd[i].style.maxWidth!="80.1%" && aPwd[i].style.display!="none"){var oDiv=document.createElement('div');oDiv.style.float="left";var oNew=aPwd[i].parentNode.insertBefore(oDiv,aPwd[i].nextSibling);oNew.innerHTML=sEye;aPwd[i].style.float="left";aPwd[i].style.maxWidth="80.1%";}
    }
  }

  function togglePwdView(este){
    var oPwd=este.parentNode.previousSibling;
    if(oPwd){
      if(oPwd.value.substring(0,5)!='Ge45T'){
        if(oPwd.type==="text"){oPwd.type="password";este.style.fillOpacity="0.5";}
        else if(oPwd.type==="password"){oPwd.type="text";este.style.fillOpacity="1";}
      }
    }
  }

  function ConsultaObjetoCorreios(sObjeto){
    var oForm=document.createElement("form");
    oForm.setAttribute("method","get");oForm.setAttribute("action","https://rastreamento.correios.com.br/app/index.php");oForm.setAttribute("target","consultaCorreio");
    var oInput=document.createElement("input");
    oInput.setAttribute("type","hidden");oInput.setAttribute("name","objetos");oInput.setAttribute("value",sObjeto);
    oForm.appendChild(oInput);
    document.getElementsByTagName("body")[0].appendChild(oForm);
    var oPopup=window.open("","consultaCorreio","top=20,left=20,height=400,width=540,resizable=yes,status=no,scrollbars=yes,toolbar=yes,menubar=no,location=no");
    oForm.submit();
    oPopup.focus();
  }

  function addFormConjBuy(IDLoja,aProds){
    if(typeof(aProds)=="object" && aProds.constructor==Array && aProds.length>0){
      var oProd,f=document.createElement("form");
      f.setAttribute("method","post");f.setAttribute("action",uk("url-add-multiple-products"));
      addFormInput(f,"hidden","PostMult","True");
      for(var i=0;i<aProds.length;i++){
        oProd=aProds[i];
        addFormInput(f,"hidden","QTIncMult_"+oProd.id,oProd.qt);
        if(oProd.Adicional1!="")addFormInput(f,"hidden","Adicional1_"+oProd.id,oProd.Adicional1);
        if(oProd.Adicional2!="")addFormInput(f,"hidden","Adicional2_"+oProd.id,oProd.Adicional2);
        if(oProd.Adicional3!="")addFormInput(f,"hidden","Adicional3_"+oProd.id,oProd.Adicional3);
        if(oProd.AdicionalD1!="")addFormInput(f,"hidden","AdicionalD1_"+oProd.id,oProd.AdicionalD1);
        if(oProd.AdicionalD2!="")addFormInput(f,"hidden","AdicionalD2_"+oProd.id,oProd.AdicionalD2);
        if(oProd.AdicionalD3!="")addFormInput(f,"hidden","AdicionalD3_"+oProd.id,oProd.AdicionalD3);
        if(oProd.Cor!="")addFormInput(f,"hidden","Cor_"+oProd.id,oProd.Cor);
      }
      document.getElementsByTagName("body")[0].appendChild(f);
      f.submit();
    }
  }
  
  function addFormInput(oForm,sType,sName,sValue){
    var i=document.createElement("input");
    i.setAttribute("type",sType);
    i.setAttribute("name",sName);
    i.setAttribute("value",sValue);
    oForm.appendChild(i);
  }

  function addConjBuyCartOnPage(IDLoja,aProds,este){
    if(typeof(aProds)=="object" && aProds.constructor==Array && aProds.length>0){
      var sParamsProd="n=1";
      for(var i=0;i<aProds.length;i++){
        var oProd=aProds[i];
        sParamsProd+="&QTIncMult_"+ oProd.id +"="+ oProd.qt;
        if(oProd.Adicional1!="")sParamsProd+="&Adicional1_"+ oProd.id +"="+ EncodeParamFC(oProd.Adicional1);
        if(oProd.Adicional2!="")sParamsProd+="&Adicional2_"+ oProd.id +"="+ EncodeParamFC(oProd.Adicional2);
        if(oProd.Adicional3!="")sParamsProd+="&Adicional3_"+ oProd.id +"="+ EncodeParamFC(oProd.Adicional3);
        if(oProd.AdicionalD1!="")sParamsProd+="&AdicionalD1_"+ oProd.id +"="+ EncodeParamFC(oProd.AdicionalD1);
        if(oProd.AdicionalD2!="")sParamsProd+="&AdicionalD2_"+ oProd.id +"="+ EncodeParamFC(oProd.AdicionalD2);
        if(oProd.AdicionalD3!="")sParamsProd+="&AdicionalD3_"+ oProd.id +"="+ EncodeParamFC(oProd.AdicionalD3);
        if(oProd.Cor!="")sParamsProd+="&Cor_"+ oProd.id +"="+ EncodeParamFC(oProd.Cor);
      }
      AjaxExecFC(uk("url-add-multiple-products"),"xml=1"+sParamsProd,true,processXMLAddMult,IDLoja,este,sParamsProd);
    }
  }

  function fnLoadScript(src,IsAsync){
    var fcw=document.createElement('script');
    fcw.type='text/javascript';
    fcw.async=IsAsync;
    fcw.src=src;
    var s=document.getElementsByTagName('script')[0];
    s.parentNode.insertBefore(fcw,s);
  }
  
  function GetID(id){return document.getElementById(id);}

  function fnClientLogout(sPag,FuncClientLogout){
    AjaxExecFC(uk("url-xml-logout"),"",false,fnProcessLogout,sPag,FuncClientLogout);
  }

  function fnProcessLogout(obj,sPag,FuncClientLogout){
    if(typeof FuncClientLogout!='undefined')FuncClientLogout(obj,sPag);
    else {
      if(sPag.search(".")==-1)window.location.href="/"+ sPag +".asp?idloja="+ FC$.IDLoja;
      else window.location.href="/"+ sPag;
    }
  }

  function fnShowImgError(este,errorImg){este.src=errorImg;}

  function fnDontGo(fnUserDontGo,oParam,sCookieName){
    if(typeof fnUserDontGo=="function"){
      if(!sCookieName)sCookieName="showedDontGoFC";
      if(!GetCookie(sCookieName)){
        var bIsMouseIn=true;
        var yMouse=99999;
        var oEventHandlers={
          mousemove:function(e){yMouse=e.clientY;},
          mouseout:function(e){return function(el){unHoverElement(el,e)}}(document)
        };
        AddEvent(document,"mousemove",oEventHandlers.mousemove);
        document.addEventListener("mouseout",oEventHandlers.mouseout,true);
      }
    }
    function unHoverElement(e,oTarget){
      var isChildOf=function(pNode,cNode){
        if(pNode===cNode)return true;
        while(cNode && cNode!==pNode)cNode=cNode.parentNode;
        return cNode===pNode;
      };
      var target=e.srcElement||e.target;
      if(!oTarget)oTarget=target;
      var relTarg=e.relatedTarget||e.toElement;
      if(document.attachEvent||(!isChildOf(oTarget,relTarg))){
        if(bIsMouseIn && yMouse<150 && !GetCookie(sCookieName)){
          FCLib$.SetCookie(sCookieName,true);
          RemoveEvent(document,"mousemove",oEventHandlers.mousemove);
          document.removeEventListener("mouseout",oEventHandlers.mouseout,true);
          if(!GetCookie("OrderCompletedFC"))fnUserDontGo(oParam);
          bIsMouseIn=false;
        }
      }
    }
  }

  onReady(function(){
    if(typeof FC$!="undefined"){
      signinFacebook();
      signinWithGoogle();
    }
  });

  function signinFacebook(){
    if(typeof FC$.FacebookSigninID!="undefined"){
      var aSigninClass=document.querySelectorAll(".FacebookSigninClass");
      if(aSigninClass.length>0 && typeof FB=="undefined"){
        window.fbAsyncInit=function(){
          FB.init({
            appId:FC$.FacebookSigninID,
            cookie:true, 
            xfbml:true,
            version:"v2.2"
          });
        };
        (function(d,s,id){
          var js,fjs=d.getElementsByTagName(s)[0];
          if(d.getElementById(id))return;
          js=d.createElement(s);js.id=id;
          js.src="//connect.facebook.net/en_US/sdk.js";
          fjs.parentNode.insertBefore(js,fjs);
        }(document,"script","facebook-jssdk"));
      }
      for(var i=0;i<aSigninClass.length;i++){
        var oBtn=aSigninClass[i];
        if(!oBtn.getAttribute("data-hasAttachedSignin")){
          oBtn.style.cursor="pointer";
          oBtn.setAttribute("data-hasAttachedSignin",true);
          FCLib$.AddEvent(oBtn,"click",fnFacebookLogin);
        }
      }
    }
  }

  function fnFacebookLogin(e){
    var oBtn=e.srcElement||e.target;
    FB.login(function(response){
      if(response.authResponse){
        fnCreateLoader();
        FB.api("/me?fields=id,name,picture,first_name,last_name,email",function(responseMe){
          GlobalSigninUser["service"]="Facebook";
          GlobalSigninUser["fullName"]=responseMe.name;
          GlobalSigninUser["firstName"]=responseMe.first_name;
          GlobalSigninUser["lastName"]=responseMe.last_name;
          GlobalSigninUser["email"]=responseMe.email;
          if(responseMe.picture.data.is_silhouette)GlobalSigninUser["pictureURL"]="";
          else GlobalSigninUser["pictureURL"]="https://graph.facebook.com/"+ responseMe.id +"/picture";
          var AccessToken=response.authResponse.accessToken;
          FCLib$.fnAjaxExecFC(uk("url-global-signin"),"service=facebook&TokenID="+AccessToken,true,fnSigninCallback,oBtn);
        });
      }
      else console.log("Facebook user cancelled login or did not fully authorize.");
    },
    {scope:"public_profile,email"});
  }

  function signinWithGoogle(){
    if(typeof FC$.GoogleSigninID!="undefined"){
      var aSigninClass=document.querySelectorAll(".GoogleSigninClass");
      if(aSigninClass.length>0){
        if(typeof google=="undefined")FCLib$.fnLoadScript("https://accounts.google.com/gsi/client",false);
        waitGoogleLoginAPI(function(){initSigninWithGoogle(aSigninClass);},1);
      }
    }
  }
  
  function waitGoogleLoginAPI(initFunc,iRetries){
    if(iRetries<100){
      if(typeof google=="undefined")setTimeout(function(){waitGoogleLoginAPI(initFunc,iRetries+1);},100);
      else initFunc();
    }
    else{
      console.log("GoogleAPI timed out");
    }
  }
  
  function initSigninWithGoogle(aSigninClass){
    if(!isGoogleInit){
      isGoogleInit=true;
      google.accounts.id.initialize({
        client_id: FC$.GoogleSigninID,
        callback: handleCredentialResponseGoogleLogin
      });
    }
    for(var i=0;i<aSigninClass.length;i++){
      var oBtn=aSigninClass[i];
      if(!oBtn.getAttribute("data-hasAttachedSignin")){
        oBtn.style.cursor="pointer";
        oBtn.setAttribute("data-hasAttachedSignin",true);
        var sTheme=oBtn.getAttribute("data-theme");if(!sTheme)sTheme="outline";
        var sSize=oBtn.getAttribute("data-size");if(!sSize)sSize="large";
        var sType=oBtn.getAttribute("data-type");if(!sType)sType="standard";
        var sText=oBtn.getAttribute("data-text");if(!sText)sText="signin_with";
        var sShape=oBtn.getAttribute("data-shape");if(!sShape)sShape="rectangular";
        google.accounts.id.renderButton(oBtn,{type:sType,text:sText,shape:sShape,theme:sTheme,size:sSize,click_listener: onClickHandlerGoogleLogin(oBtn)});   
      }
    }
  } 

  function onClickHandlerGoogleLogin(oBtn){
    oBtnLoginGoogle=oBtn;
  }
    
  function handleCredentialResponseGoogleLogin(response) {  
    fnCreateLoader();
    var id_token=response.credential;
    var profile=JSON.parse(atob(id_token.split('.')[1]));
    GlobalSigninUser["service"]="Google";
    GlobalSigninUser["fullName"]=profile.name;
    GlobalSigninUser["firstName"]=profile.given_name;
    GlobalSigninUser["lastName"]=profile.family_name;
    GlobalSigninUser["email"]=profile.email;
    GlobalSigninUser["pictureURL"]=profile.picture;
    FCLib$.fnAjaxExecFC(uk("url-global-signin"),"service=google&TokenID="+id_token,true,fnSigninGoogleCallback);
  }

  function fnSigninGoogleCallback(oHTTP){
    var sHTTP=oHTTP.responseText;
    if(sHTTP!=""){
      var oJSON=null;
      try{oJSON=JSON.parse(sHTTP);}
      catch(e){console.log("invalid JSON from url-global-signin");}
      if(oJSON){
        if(oJSON.iErr==0 || oJSON.iErr==8){
          var oSuccessFunc=oBtnLoginGoogle.getAttribute("data-loginsuccess");
          if(typeof window[oSuccessFunc]=="function")window[oSuccessFunc](GlobalSigninUser);
        }
      }
    }
    else{console.log("blank response from url-global-signin");}
    fnRemoveLoader();
  }

  function fnSigninCallback(oHTTP,oBtn){
    var sHTTP=oHTTP.responseText;
    if(sHTTP!=""){
      var oJSON=null;
      try{oJSON=JSON.parse(sHTTP);}
      catch(e){console.log("invalid JSON from url-global-signin");}
      if(oJSON){
        if(oJSON.iErr==0 || oJSON.iErr==8){
          var oSuccessFunc=oBtn.getAttribute("data-loginsuccess");
          if(typeof window[oSuccessFunc]=="function")window[oSuccessFunc](GlobalSigninUser);
        }
      }
    }
    else{console.log("blank response from url-global-signin");}
    fnRemoveLoader();
  }

  function fnCreateLoader(){
    if(typeof FuncCreateLoader!='undefined')FuncCreateLoader();
    else {
      var oDivBackground=document.createElement("div");
      oDivBackground.setAttribute("id","divContainerLoader");
      oDivBackground.style.cssText="width:100%;height:100%;position:fixed;background-color:rgba(255,255,255,0.7);top:0;left:0;text-align:center;z-index:9999;";
      document.body.appendChild(oDivBackground);
      var imgLoader=document.createElement("img");
      imgLoader.src="/images/Loader.gif";
      imgLoader.style.cssText="margin:20% 0 0 0;";
      oDivBackground.appendChild(imgLoader);
    }
  }

  function fnRemoveLoader(){
    if(typeof FuncRemoveLoader!='undefined')FuncRemoveLoader();
    else {
      var oDivBackground=document.getElementById("divContainerLoader");
      oDivBackground.parentNode.removeChild(oDivBackground);
    }
  }

  var fnCallbackSuggestions=null,fnCallbackSuggestionsParam1=null,fnCallbackSuggestionsParam2=null,fnCallbackSuggestionsParam3=null,bDoneSuggestions=false;
  function fnGetSuggestions(sTerm,IsAsync,fnCallback,sParam1,sParam2,sParam3){
    "use strict";
    if(1==2 && sTerm!=""){
      fnCallbackSuggestions=fnCallback;
      fnCallbackSuggestionsParam1=sParam1;fnCallbackSuggestionsParam2=sParam2;fnCallbackSuggestionsParam3=sParam3;
      FCLib$.bDoneSuggestions=false;
      var sURLGoogle="https://suggestqueries.google.com/complete/search?client=youtube&jsonp=FCLib$.fnSuggestCallBack&q="+encodeURI(sTerm);
      FCLib$.fnLoadScript(sURLGoogle,IsAsync);
    }
  }
  function fnSuggestCallBack(aRet){
    "use strict";
    FCLib$.bDoneSuggestions=true;
    var aTerms=[];
    if(aRet.constructor==Array && aRet.length>0){
      var sTerm=aRet[0];
      var aResults=aRet[1];
      var iResults=aResults.length;
      var j=0;
      for(var i=0;i<iResults;i++)if(sTerm!=aResults[i][0])aTerms[j++]=aResults[i][0];
    }
    if(fnCallbackSuggestions)fnCallbackSuggestions(aTerms,fnCallbackSuggestionsParam1,fnCallbackSuggestionsParam2,fnCallbackSuggestionsParam3);
  }
  function fnGetSearchURL(sTerm,sParamName){
    "use strict";
    var sURL=document.location.href;
    var iPosIni=sURL.toLowerCase().indexOf(sParamName+"=");
    if(iPosIni>=0)var sCharFim="&";
    else{
      iPosIni=sURL.toLowerCase().indexOf(sParamName+",");
      var sCharFim=","
    }
    if(iPosIni<0)return "#";
    iPosIni+=(sParamName+"=").length;
    var sURLFinal=sURL.substring(0,iPosIni) + sTerm;
    var iPosFim=sURL.substring(iPosIni).indexOf(sCharFim);
    if(iPosFim>=0)sURLFinal+=sURL.substring(iPosIni+iPosFim);
    return sURLFinal;
  }
  function fnOrderTrack(sExt){
    var oOrderOut=FCLib$.GetID("idOrderStatusFC");
    if(typeof(FCLib$.pOrderTrack)=="object" && FCLib$.pOrderTrack!=null && oOrderOut){
      var oPar=FCLib$.pOrderTrack;
      var sStatus=oPar.status;
      if(sStatus!="2"){
        var iOut="";
        if(sStatus=="7" && oPar.receivingDate!="")iOut="4";
        else if(sStatus=="7")iOut="3";
        else if(sStatus=="5" || sStatus=="6")iOut="2";
        else iOut="1"; 
        if(sExt==undefined){oOrderOut.innerHTML="<img src='/images/msg_status_"+ FC$.Language +"_0"+ iOut +".svg'>";}
        else{oOrderOut.innerHTML="<img src='"+ FC$.PathImg +"track_status_0"+ iOut +"."+ sExt +"'>";} 
      }
    }
  }

  var bGotRecaptchaToken=false;
  function fnRecaptchaInit(sRecaptchaSiteKey,sRecaptchaLabel,fnCallback){
    setTimeout(function(){
      if(!bGotRecaptchaToken){
        fnRecaptchaInit(sRecaptchaSiteKey,sRecaptchaLabel,fnCallback);
      }
    },3000);
    if(typeof grecaptcha!="undefined"){
      grecaptcha.ready(function(){
        grecaptcha.execute(sRecaptchaSiteKey,{action:sRecaptchaLabel}).then(
          function(token){
            if(1==1 || !bGotRecaptchaToken){
              bGotRecaptchaToken=true;fnCallback(token);
            }
          }
        );
      });
    }
    else fnLoadScript("https://www.google.com/recaptcha/api.js?render="+ sRecaptchaSiteKey,false);
  }

  function RecoverCart(id){
    FCLib$.fnAjaxExecFC(uk("url-add-multiple-products"),"autorec=1&idr="+id,false,fnRecoverCartCallback,id);
  }

  function fnRecoverCartCallback(oHTTP,id){
    if(typeof FuncRecoverCartCallback!='undefined')FuncRecoverCartCallback();
  }

  function fnFBAddToCart(oProd){
    fbq("track", "AddToCart", {
      content_type: "product",
      content_ids: [oProd.IDProduto],
      content_ids_parent: [oProd.IDProdutoPai],
      content_name: [oProd.name],
      content_category: [oProd.category],
      value: oProd.priceNum,
      currency: fnGetCurrency()
    });
  }

  function fnGoogleAddToCart(oProd,iQty){
    if(FC$.isTest)console.log("fnGAAddToCart (ID:"+ FC$.GA +") [add_to_cart]");
    if(typeof gtag!='undefined'){
      gtag('event', 'add_to_cart', {
        currency: fnGetCurrency(),
        items: [{
          item_id: oProd.IDProduto,
          item_name: oProd.name,
          item_category: oProd.category,
          price: oProd.priceNum,
          currency: fnGetCurrency(),
          quantity: iQty
        }],
        value: oProd.priceNum
      });
    }
  }

  function fnPinterestAddToCart(oProd,iQty){
    var sPinterestEventID="id."+ Math.floor(Math.random()*1000000000000);
    if(FC$.isTest)console.log("fnPinterestAddToCart (Tag ID:"+ FC$.PinterestTagID +") sPinterestEventID [addtocart]",sPinterestEventID);
    pintrk("track","addtocart",{
      event_id: sPinterestEventID,
      currency: fnGetCurrency(),
      value: oProd.priceNum,
      line_items:[
        {
          "product_name": oProd.name,
          "product_id": oProd.IDProduto,
          "product_price": oProd.priceNum,
          "product_category": oProd.category,
          "product_quantity": iQty
        }
      ]
    });
  }

  function fnPinterestPageVisitProd(oProd){
    var sPinterestEventID="id."+ Math.floor(Math.random()*1000000000000);
    if(FC$.isTest)console.log("fnPinterestPageVisitProd (Tag ID:"+ FC$.PinterestTagID +") sPinterestEventID [pagevisit]",sPinterestEventID);
    pintrk("track","pagevisit",{
      event_id: sPinterestEventID,
      currency: fnGetCurrency(),
      value: oProd.PrecoNum,
      line_items:[
        {
          "product_name": oProd.ProdName,
          "product_id": oProd.IDProduto,
          "product_price": oProd.PrecoNum,
          "product_category": oProd.ProdCategory
        }
      ]
    });
  }

  function fnTikTokAddToCart(oProd,iQty){
    if(FC$.isTest)console.log("fnTikTokAddToCart (Tag ID:"+ FC$.TikTokPixelID +")");
    var sTikTokEventID="id."+ Math.floor(Math.random()*1000000000000);
    ttq.track('AddToCart',{
      'event_id':sTikTokEventID,
      'contents':[
        {
          'content_id':oProd.IDProduto,
          'content_name':oProd.name,
          'content_type':'product',
          'quantity':iQty,
          'price':oProd.priceNum,
        }],
        'value':oProd.priceNum,
        'currency':fnGetCurrency()
      }
    );
  }

  function fnGetCurrency(){
    var sCurrency="";
    if(FC$.Currency=="R$")sCurrency="BRL";
    else if(FC$.Currency=="US$")sCurrency="USD";
    else if(FC$.Currency=="EUR" || FC$.LanguageCountry=="�")sCurrency="EUR";
    else if(FC$.Currency=="A$")sCurrency="AUD";
    else if(FC$.Currency=="�")sCurrency="JPY";
    else if(FC$.Currency=="Mex$")sCurrency="MXN";
    else if(FC$.Currency=="NIS")sCurrency="ILS";
    else if(FC$.Currency=="�")sCurrency="GBP";
    else if(FC$.Currency=="ARG$")sCurrency="ARS";
    return sCurrency;
  }

  function vexLoad(){
    /* vex.js, vex.dialog.js 2.2.1 */
    (function(){var a;a=function(a){var b,c;return b=!1,a(function(){var d;return d=(document.body||document.documentElement).style,b=void 0!==d.animation||void 0!==d.WebkitAnimation||void 0!==d.MozAnimation||void 0!==d.MsAnimation||void 0!==d.OAnimation,a(window).bind("keyup.vex",function(a){return 27===a.keyCode?c.closeByEscape():void 0})}),c={globalID:1,animationEndEvent:"animationend webkitAnimationEnd mozAnimationEnd MSAnimationEnd oanimationend",baseClassNames:{vex:"vex",content:"vex-content",overlay:"vex-overlay",close:"vex-close",closing:"vex-closing",open:"vex-open"},defaultOptions:{content:"",showCloseButton:!0,escapeButtonCloses:!0,overlayClosesOnClick:!0,appendLocation:"body",className:"",css:{},overlayClassName:"",overlayCSS:{},contentClassName:"",contentCSS:{},closeClassName:"",closeCSS:{}},open:function(b){return b=a.extend({},c.defaultOptions,b),b.id=c.globalID,c.globalID+=1,b.$vex=a("<div>").addClass(c.baseClassNames.vex).addClass(b.className).css(b.css).data({vex:b}),b.$vexOverlay=a("<div>").addClass(c.baseClassNames.overlay).addClass(b.overlayClassName).css(b.overlayCSS).data({vex:b}),b.overlayClosesOnClick&&b.$vexOverlay.bind("click.vex",function(b){return b.target===this?c.close(a(this).data().vex.id):void 0}),b.$vex.append(b.$vexOverlay),b.$vexContent=a("<div>").addClass(c.baseClassNames.content).addClass(b.contentClassName).css(b.contentCSS).append(b.content).data({vex:b}),b.$vex.append(b.$vexContent),b.showCloseButton&&(b.$closeButton=a("<div>").addClass(c.baseClassNames.close).addClass(b.closeClassName).css(b.closeCSS).data({vex:b}).bind("click.vex",function(){return c.close(a(this).data().vex.id)}),b.$vexContent.append(b.$closeButton)),a(b.appendLocation).append(b.$vex),c.setupBodyClassName(b.$vex),b.afterOpen&&b.afterOpen(b.$vexContent,b),setTimeout(function(){return b.$vexContent.trigger("vexOpen",b)},0),b.$vexContent},getAllVexes:function(){return a("."+c.baseClassNames.vex+':not(".'+c.baseClassNames.closing+'") .'+c.baseClassNames.content)},getVexByID:function(b){return c.getAllVexes().filter(function(){return a(this).data().vex.id===b})},close:function(a){var b;if(!a){if(b=c.getAllVexes().last(),!b.length)return!1;a=b.data().vex.id}return c.closeByID(a)},closeAll:function(){var b;return b=c.getAllVexes().map(function(){return a(this).data().vex.id}).toArray(),(null!=b?b.length:void 0)?(a.each(b.reverse(),function(a,b){return c.closeByID(b)}),!0):!1},closeByID:function(d){var e,f,g,h,i;return f=c.getVexByID(d),f.length?(e=f.data().vex.$vex,i=a.extend({},f.data().vex),g=function(){return i.beforeClose?i.beforeClose(f,i):void 0},h=function(){return f.trigger("vexClose",i),e.remove(),a("body").trigger("vexAfterClose",i),i.afterClose?i.afterClose(f,i):void 0},b?(g(),e.unbind(c.animationEndEvent).bind(c.animationEndEvent,function(){return h()}).addClass(c.baseClassNames.closing)):(g(),h()),!0):void 0},closeByEscape:function(){var b,d,e;return e=c.getAllVexes().map(function(){return a(this).data().vex.id}).toArray(),(null!=e?e.length:void 0)?(d=Math.max.apply(Math,e),b=c.getVexByID(d),b.data().vex.escapeButtonCloses!==!0?!1:c.closeByID(d)):!1},setupBodyClassName:function(){return a("body").bind("vexOpen.vex",function(){return a("body").addClass(c.baseClassNames.open)}).bind("vexAfterClose.vex",function(){return c.getAllVexes().length?void 0:a("body").removeClass(c.baseClassNames.open)})},hideLoading:function(){return a(".vex-loading-spinner").remove()},showLoading:function(){return c.hideLoading(),a("body").append('<div class="vex-loading-spinner '+c.defaultOptions.className+'"></div>')}}},"function"==typeof define&&define.amd?define(["jquery"],a):"object"==typeof exports?module.exports=a(require("jquery")):window.vex=a(jQuery)}).call(this),function(){var a;a=function(a,b){var c,d;return null==b?a.error("Vex is required to use vex.dialog"):(c=function(b){var c;return c={},a.each(b.serializeArray(),function(){return c[this.name]?(c[this.name].push||(c[this.name]=[c[this.name]]),c[this.name].push(this.value||"")):c[this.name]=this.value||""}),c},d={},d.buttons={YES:{text:"OK",type:"submit",className:"vex-dialog-button-primary"},NO:{text:"Cancel",type:"button",className:"vex-dialog-button-secondary",click:function(a){return a.data().vex.value=!1,b.close(a.data().vex.id)}}},d.defaultOptions={callback:function(){},afterOpen:function(){},message:"Message",input:'<input name="vex" type="hidden" value="_vex-empty-value" />',value:!1,buttons:[d.buttons.YES,d.buttons.NO],showCloseButton:!1,onSubmit:function(e){var f,g;return f=a(this),g=f.parent(),e.preventDefault(),e.stopPropagation(),g.data().vex.value=d.getFormValueOnSubmit(c(f)),b.close(g.data().vex.id)},focusFirstInput:!0},d.defaultAlertOptions={message:"Alert",buttons:[d.buttons.YES]},d.defaultConfirmOptions={message:"Confirm"},d.open=function(c){var e;return c=a.extend({},b.defaultOptions,d.defaultOptions,c),c.content=d.buildDialogForm(c),c.beforeClose=function(a){return c.callback(a.data().vex.value)},e=b.open(c),c.focusFirstInput&&e.find('input[type="submit"], textarea, input[type="date"], input[type="datetime"], input[type="datetime-local"], input[type="email"], input[type="month"], input[type="number"], input[type="password"], input[type="search"], input[type="tel"], input[type="text"], input[type="time"], input[type="url"], input[type="week"]').first().focus(),e},d.alert=function(b){return"string"==typeof b&&(b={message:b}),b=a.extend({},d.defaultAlertOptions,b),d.open(b)},d.confirm=function(b){return"string"==typeof b?a.error("dialog.confirm(options) requires options.callback."):(b=a.extend({},d.defaultConfirmOptions,b),d.open(b))},d.prompt=function(b){var c;return"string"==typeof b?a.error("dialog.prompt(options) requires options.callback."):(c={message:'<label for="vex">'+(b.label||"Prompt:")+"</label>",input:'<input name="vex" type="text" class="vex-dialog-prompt-input" placeholder="'+(b.placeholder||"")+'"  value="'+(b.value||"")+'" />'},b=a.extend({},c,b),d.open(b))},d.buildDialogForm=function(b){var c,e,f;return c=a('<form class="vex-dialog-form" />'),f=a('<div class="vex-dialog-message" />'),e=a('<div class="vex-dialog-input" />'),c.append(f.append(b.message)).append(e.append(b.input)).append(d.buttonsToDOM(b.buttons)).bind("submit.vex",b.onSubmit),c},d.getFormValueOnSubmit=function(a){return a.vex||""===a.vex?"_vex-empty-value"===a.vex?!0:a.vex:a},d.buttonsToDOM=function(c){var d;return d=a('<div class="vex-dialog-buttons" />'),a.each(c,function(e,f){var g;return g=a('<input type="'+f.type+'" />').val(f.text).addClass(f.className+" vex-dialog-button "+(0===e?"vex-first ":"")+(e===c.length-1?"vex-last ":"")).bind("click.vex",function(c){return f.click?f.click(a(this).parents("."+b.baseClassNames.content),c):void 0}),g.appendTo(d)}),d},d)},"function"==typeof define&&define.amd?define(["jquery","vex"],a):"object"==typeof exports?module.exports=a(require("jquery"),require("vex")):window.vex.dialog=a(window.jQuery,window.vex)}.call(this);
    vex.defaultOptions.className="vex-theme-default";
    var oStyle=document.createElement("style");
    oStyle.innerHTML=".vex,.vex-loading-spinner,.vex-overlay{position:fixed;top:0;right:0;bottom:0;left:0}@keyframes vex-fadein{0%{opacity:0}100%{opacity:1}}@-webkit-keyframes vex-fadein{0%{opacity:0}100%{opacity:1}}@-moz-keyframes vex-fadein{0%{opacity:0}100%{opacity:1}}@-ms-keyframes vex-fadein{0%{opacity:0}100%{opacity:1}}@-o-keyframes vex-fadein{0%{opacity:0}100%{opacity:1}}@keyframes vex-fadeout{0%{opacity:1}100%{opacity:0}}@-webkit-keyframes vex-fadeout{0%{opacity:1}100%{opacity:0}}@-moz-keyframes vex-fadeout{0%{opacity:1}100%{opacity:0}}@-ms-keyframes vex-fadeout{0%{opacity:1}100%{opacity:0}}@-o-keyframes vex-fadeout{0%{opacity:1}100%{opacity:0}}@keyframes vex-rotation{0%{transform:rotate(0);-webkit-transform:rotate(0);-moz-transform:rotate(0);-ms-transform:rotate(0);-o-transform:rotate(0)}100%{transform:rotate(359deg);-webkit-transform:rotate(359deg);-moz-transform:rotate(359deg);-ms-transform:rotate(359deg);-o-transform:rotate(359deg)}}@-webkit-keyframes vex-rotation{0%{transform:rotate(0);-webkit-transform:rotate(0);-moz-transform:rotate(0);-ms-transform:rotate(0);-o-transform:rotate(0)}100%{transform:rotate(359deg);-webkit-transform:rotate(359deg);-moz-transform:rotate(359deg);-ms-transform:rotate(359deg);-o-transform:rotate(359deg)}}@-moz-keyframes vex-rotation{0%{transform:rotate(0);-webkit-transform:rotate(0);-moz-transform:rotate(0);-ms-transform:rotate(0);-o-transform:rotate(0)}100%{transform:rotate(359deg);-webkit-transform:rotate(359deg);-moz-transform:rotate(359deg);-ms-transform:rotate(359deg);-o-transform:rotate(359deg)}}@-ms-keyframes vex-rotation{0%{transform:rotate(0);-webkit-transform:rotate(0);-moz-transform:rotate(0);-ms-transform:rotate(0);-o-transform:rotate(0)}100%{transform:rotate(359deg);-webkit-transform:rotate(359deg);-moz-transform:rotate(359deg);-ms-transform:rotate(359deg);-o-transform:rotate(359deg)}}@-o-keyframes vex-rotation{0%{transform:rotate(0);-webkit-transform:rotate(0);-moz-transform:rotate(0);-ms-transform:rotate(0);-o-transform:rotate(0)}100%{transform:rotate(359deg);-webkit-transform:rotate(359deg);-moz-transform:rotate(359deg);-ms-transform:rotate(359deg);-o-transform:rotate(359deg)}}.vex,.vex *,.vex :after,.vex :before{-webkit-box-sizing:border-box;-moz-box-sizing:border-box;box-sizing:border-box}.vex{overflow:auto;-webkit-overflow-scrolling:touch;z-index:1111}.vex-overlay{animation:vex-fadein .5s;-webkit-animation:vex-fadein .5s;-moz-animation:vex-fadein .5s;-ms-animation:vex-fadein .5s;-o-animation:vex-fadein .5s;-webkit-backface-visibility:hidden;background:rgba(0,0,0,.4)}.vex-content,.vex-loading-spinner{-webkit-backface-visibility:hidden;background:#fff}.vex.vex-closing .vex-overlay{animation:vex-fadeout .5s;-webkit-animation:vex-fadeout .5s;-moz-animation:vex-fadeout .5s;-ms-animation:vex-fadeout .5s;-o-animation:vex-fadeout .5s;-webkit-backface-visibility:hidden}.vex-content{animation:vex-fadein .5s;-webkit-animation:vex-fadein .5s;-moz-animation:vex-fadein .5s;-ms-animation:vex-fadein .5s;-o-animation:vex-fadein .5s}.vex.vex-closing .vex-content{animation:vex-fadeout .5s;-webkit-animation:vex-fadeout .5s;-moz-animation:vex-fadeout .5s;-ms-animation:vex-fadeout .5s;-o-animation:vex-fadeout .5s;-webkit-backface-visibility:hidden}.vex-close:before{font-family:Arial,sans-serif;content:'\\00D7'}.vex-dialog-form{margin:0}.vex-dialog-button{-webkit-appearance:none;cursor:pointer}.vex-loading-spinner{animation:vex-rotation .7s linear infinite;-webkit-animation:vex-rotation .7s linear infinite;-moz-animation:vex-rotation .7s linear infinite;-ms-animation:vex-rotation .7s linear infinite;-o-animation:vex-rotation .7s linear infinite;-webkit-box-shadow:0 0 1em rgba(0,0,0,.1);-moz-box-shadow:0 0 1em rgba(0,0,0,.1);box-shadow:0 0 1em rgba(0,0,0,.1);z-index:1112;margin:auto;height:2em;width:2em}body.vex-open{overflow:hidden}@keyframes vex-flyin{0%{opacity:0;transform:translateY(-40px);-webkit-transform:translateY(-40px);-moz-transform:translateY(-40px);-ms-transform:translateY(-40px);-o-transform:translateY(-40px)}100%{opacity:1;transform:translateY(0);-webkit-transform:translateY(0);-moz-transform:translateY(0);-ms-transform:translateY(0);-o-transform:translateY(0)}}@-webkit-keyframes vex-flyin{0%{opacity:0;transform:translateY(-40px);-webkit-transform:translateY(-40px);-moz-transform:translateY(-40px);-ms-transform:translateY(-40px);-o-transform:translateY(-40px)}100%{opacity:1;transform:translateY(0);-webkit-transform:translateY(0);-moz-transform:translateY(0);-ms-transform:translateY(0);-o-transform:translateY(0)}}@-moz-keyframes vex-flyin{0%{opacity:0;transform:translateY(-40px);-webkit-transform:translateY(-40px);-moz-transform:translateY(-40px);-ms-transform:translateY(-40px);-o-transform:translateY(-40px)}100%{opacity:1;transform:translateY(0);-webkit-transform:translateY(0);-moz-transform:translateY(0);-ms-transform:translateY(0);-o-transform:translateY(0)}}@-ms-keyframes vex-flyin{0%{opacity:0;transform:translateY(-40px);-webkit-transform:translateY(-40px);-moz-transform:translateY(-40px);-ms-transform:translateY(-40px);-o-transform:translateY(-40px)}100%{opacity:1;transform:translateY(0);-webkit-transform:translateY(0);-moz-transform:translateY(0);-ms-transform:translateY(0);-o-transform:translateY(0)}}@-o-keyframes vex-flyin{0%{opacity:0;transform:translateY(-40px);-webkit-transform:translateY(-40px);-moz-transform:translateY(-40px);-ms-transform:translateY(-40px);-o-transform:translateY(-40px)}100%{opacity:1;transform:translateY(0);-webkit-transform:translateY(0);-moz-transform:translateY(0);-ms-transform:translateY(0);-o-transform:translateY(0)}}@keyframes vex-flyout{0%{opacity:1;transform:translateY(0);-webkit-transform:translateY(0);-moz-transform:translateY(0);-ms-transform:translateY(0);-o-transform:translateY(0)}100%{opacity:0;transform:translateY(-40px);-webkit-transform:translateY(-40px);-moz-transform:translateY(-40px);-ms-transform:translateY(-40px);-o-transform:translateY(-40px)}}@-webkit-keyframes vex-flyout{0%{opacity:1;transform:translateY(0);-webkit-transform:translateY(0);-moz-transform:translateY(0);-ms-transform:translateY(0);-o-transform:translateY(0)}100%{opacity:0;transform:translateY(-40px);-webkit-transform:translateY(-40px);-moz-transform:translateY(-40px);-ms-transform:translateY(-40px);-o-transform:translateY(-40px)}}@-moz-keyframes vex-flyout{0%{opacity:1;transform:translateY(0);-webkit-transform:translateY(0);-moz-transform:translateY(0);-ms-transform:translateY(0);-o-transform:translateY(0)}100%{opacity:0;transform:translateY(-40px);-webkit-transform:translateY(-40px);-moz-transform:translateY(-40px);-ms-transform:translateY(-40px);-o-transform:translateY(-40px)}}@-ms-keyframes vex-flyout{0%{opacity:1;transform:translateY(0);-webkit-transform:translateY(0);-moz-transform:translateY(0);-ms-transform:translateY(0);-o-transform:translateY(0)}100%{opacity:0;transform:translateY(-40px);-webkit-transform:translateY(-40px);-moz-transform:translateY(-40px);-ms-transform:translateY(-40px);-o-transform:translateY(-40px)}}@-o-keyframes vex-flyout{0%{opacity:1;transform:translateY(0);-webkit-transform:translateY(0);-moz-transform:translateY(0);-ms-transform:translateY(0);-o-transform:translateY(0)}100%{opacity:0;transform:translateY(-40px);-webkit-transform:translateY(-40px);-moz-transform:translateY(-40px);-ms-transform:translateY(-40px);-o-transform:translateY(-40px)}}@keyframes vex-pulse{0%,100%{-webkit-box-shadow:inset 0 0 0 300px transparent;-moz-box-shadow:inset 0 0 0 300px transparent;box-shadow:inset 0 0 0 300px transparent}70%{-webkit-box-shadow:inset 0 0 0 300px rgba(255,255,255,.25);-moz-box-shadow:inset 0 0 0 300px rgba(255,255,255,.25);box-shadow:inset 0 0 0 300px rgba(255,255,255,.25)}}@-webkit-keyframes vex-pulse{0%,100%{-webkit-box-shadow:inset 0 0 0 300px transparent;-moz-box-shadow:inset 0 0 0 300px transparent;box-shadow:inset 0 0 0 300px transparent}70%{-webkit-box-shadow:inset 0 0 0 300px rgba(255,255,255,.25);-moz-box-shadow:inset 0 0 0 300px rgba(255,255,255,.25);box-shadow:inset 0 0 0 300px rgba(255,255,255,.25)}}@-moz-keyframes vex-pulse{0%,100%{-webkit-box-shadow:inset 0 0 0 300px transparent;-moz-box-shadow:inset 0 0 0 300px transparent;box-shadow:inset 0 0 0 300px transparent}70%{-webkit-box-shadow:inset 0 0 0 300px rgba(255,255,255,.25);-moz-box-shadow:inset 0 0 0 300px rgba(255,255,255,.25);box-shadow:inset 0 0 0 300px rgba(255,255,255,.25)}}@-ms-keyframes vex-pulse{0%,100%{-webkit-box-shadow:inset 0 0 0 300px transparent;-moz-box-shadow:inset 0 0 0 300px transparent;box-shadow:inset 0 0 0 300px transparent}70%{-webkit-box-shadow:inset 0 0 0 300px rgba(255,255,255,.25);-moz-box-shadow:inset 0 0 0 300px rgba(255,255,255,.25);box-shadow:inset 0 0 0 300px rgba(255,255,255,.25)}}@-o-keyframes vex-pulse{0%,100%{-webkit-box-shadow:inset 0 0 0 300px transparent;-moz-box-shadow:inset 0 0 0 300px transparent;box-shadow:inset 0 0 0 300px transparent}70%{-webkit-box-shadow:inset 0 0 0 300px rgba(255,255,255,.25);-moz-box-shadow:inset 0 0 0 300px rgba(255,255,255,.25);box-shadow:inset 0 0 0 300px rgba(255,255,255,.25)}}.vex.vex-theme-default{padding-top:160px;padding-bottom:160px}.vex.vex-theme-default.vex-closing .vex-content{animation:vex-flyout .5s;-webkit-animation:vex-flyout .5s;-moz-animation:vex-flyout .5s;-ms-animation:vex-flyout .5s;-o-animation:vex-flyout .5s;-webkit-backface-visibility:hidden}.vex.vex-theme-default .vex-content{animation:vex-flyin .5s;-webkit-animation:vex-flyin .5s;-moz-animation:vex-flyin .5s;-ms-animation:vex-flyin .5s;-o-animation:vex-flyin .5s;-webkit-backface-visibility:hidden;-webkit-border-radius:5px;-moz-border-radius:5px;-ms-border-radius:5px;-o-border-radius:5px;border-radius:5px;font-family:'Helvetica Neue',sans-serif;background:#f0f0f0;color:#444;padding:1em;position:relative;margin:0 auto;max-width:100%;width:450px;font-size:1.1em;line-height:1.5em}.vex.vex-theme-default .vex-content h1,.vex.vex-theme-default .vex-content h2,.vex.vex-theme-default .vex-content h3,.vex.vex-theme-default .vex-content h4,.vex.vex-theme-default .vex-content h5,.vex.vex-theme-default .vex-content h6,.vex.vex-theme-default .vex-content li,.vex.vex-theme-default .vex-content p,.vex.vex-theme-default .vex-content ul{color:inherit}.vex.vex-theme-default .vex-close{-webkit-border-radius:5px;-moz-border-radius:5px;-ms-border-radius:5px;-o-border-radius:5px;border-radius:5px;position:absolute;top:0;right:0;cursor:pointer}.vex.vex-theme-default .vex-close:before{-webkit-border-radius:3px;-moz-border-radius:3px;-ms-border-radius:3px;-o-border-radius:3px;border-radius:3px;position:absolute;content:'\\00D7';font-size:26px;font-weight:400;line-height:31px;height:30px;width:30px;text-align:center;top:3px;right:3px;color:#bbb;background:0 0}.vex.vex-theme-default .vex-close:active:before,.vex.vex-theme-default .vex-close:hover:before{color:#777;background:#e0e0e0}.vex.vex-theme-default .vex-dialog-form .vex-dialog-message{margin-bottom:.5em}.vex.vex-theme-default .vex-dialog-form .vex-dialog-input{margin-bottom:1em}.vex.vex-theme-default .vex-dialog-form .vex-dialog-input input[type=tel],.vex.vex-theme-default .vex-dialog-form .vex-dialog-input input[type=text],.vex.vex-theme-default .vex-dialog-form .vex-dialog-input input[type=time],.vex.vex-theme-default .vex-dialog-form .vex-dialog-input input[type=url],.vex.vex-theme-default .vex-dialog-form .vex-dialog-input input[type=week],.vex.vex-theme-default .vex-dialog-form .vex-dialog-input input[type=date],.vex.vex-theme-default .vex-dialog-form .vex-dialog-input input[type=datetime],.vex.vex-theme-default .vex-dialog-form .vex-dialog-input input[type=datetime-local],.vex.vex-theme-default .vex-dialog-form .vex-dialog-input input[type=email],.vex.vex-theme-default .vex-dialog-form .vex-dialog-input input[type=month],.vex.vex-theme-default .vex-dialog-form .vex-dialog-input input[type=number],.vex.vex-theme-default .vex-dialog-form .vex-dialog-input input[type=password],.vex.vex-theme-default .vex-dialog-form .vex-dialog-input input[type=search],.vex.vex-theme-default .vex-dialog-form .vex-dialog-input textarea{-webkit-border-radius:3px;-moz-border-radius:3px;-ms-border-radius:3px;-o-border-radius:3px;border-radius:3px;background:#fff;width:100%;padding:.25em .67em;border:0;font-family:inherit;font-weight:inherit;font-size:inherit;min-height:2.5em;margin:0 0 .25em}.vex.vex-theme-default .vex-dialog-form .vex-dialog-input input[type=tel]:focus,.vex.vex-theme-default .vex-dialog-form .vex-dialog-input input[type=text]:focus,.vex.vex-theme-default .vex-dialog-form .vex-dialog-input input[type=time]:focus,.vex.vex-theme-default .vex-dialog-form .vex-dialog-input input[type=url]:focus,.vex.vex-theme-default .vex-dialog-form .vex-dialog-input input[type=week]:focus,.vex.vex-theme-default .vex-dialog-form .vex-dialog-input input[type=date]:focus,.vex.vex-theme-default .vex-dialog-form .vex-dialog-input input[type=datetime]:focus,.vex.vex-theme-default .vex-dialog-form .vex-dialog-input input[type=datetime-local]:focus,.vex.vex-theme-default .vex-dialog-form .vex-dialog-input input[type=email]:focus,.vex.vex-theme-default .vex-dialog-form .vex-dialog-input input[type=month]:focus,.vex.vex-theme-default .vex-dialog-form .vex-dialog-input input[type=number]:focus,.vex.vex-theme-default .vex-dialog-form .vex-dialog-input input[type=password]:focus,.vex.vex-theme-default .vex-dialog-form .vex-dialog-input input[type=search]:focus,.vex.vex-theme-default .vex-dialog-form .vex-dialog-input textarea:focus{-webkit-box-shadow:inset 0 0 0 2px #8dbdf1;-moz-box-shadow:inset 0 0 0 2px #8dbdf1;box-shadow:inset 0 0 0 2px #8dbdf1;outline:0}.vex.vex-theme-default .vex-dialog-form .vex-dialog-buttons:after{content:'';display:table;clear:both}.vex.vex-theme-default .vex-dialog-button{-webkit-border-radius:3px;-moz-border-radius:3px;-ms-border-radius:3px;-o-border-radius:3px;border-radius:3px;border:0;float:right;margin:0 0 0 .5em;font-family:inherit;text-transform:uppercase;letter-spacing:.1em;font-size:.8em;line-height:1em;padding:.75em 2em}.vex.vex-theme-default .vex-dialog-button.vex-last{margin-left:0}.vex.vex-theme-default .vex-dialog-button:focus{animation:vex-pulse 1.1s infinite;-webkit-animation:vex-pulse 1.1s infinite;-moz-animation:vex-pulse 1.1s infinite;-ms-animation:vex-pulse 1.1s infinite;-o-animation:vex-pulse 1.1s infinite;-webkit-backface-visibility:hidden;outline:0}@media (max-width:568px){.vex.vex-theme-default .vex-dialog-button:focus{animation:none;-webkit-animation:none;-moz-animation:none;-ms-animation:none;-o-animation:none;-webkit-backface-visibility:hidden}}.vex.vex-theme-default .vex-dialog-button.vex-dialog-button-primary{background:#3288e6;color:#fff}.vex.vex-theme-default .vex-dialog-button.vex-dialog-button-secondary{background:#e0e0e0;color:#777}.vex-loading-spinner.vex-theme-default{-webkit-box-shadow:0 0 0 .5em #f0f0f0,0 0 1px .5em rgba(0,0,0,.3);-moz-box-shadow:0 0 0 .5em #f0f0f0,0 0 1px .5em rgba(0,0,0,.3);box-shadow:0 0 0 .5em #f0f0f0,0 0 1px .5em rgba(0,0,0,.3);-webkit-border-radius:100%;-moz-border-radius:100%;-ms-border-radius:100%;-o-border-radius:100%;border-radius:100%;background:#f0f0f0;border:.2em solid transparent;border-top-color:#bbb;top:-1.1em;bottom:auto}";
    document.head.appendChild(oStyle);
  }
  onReady(function(){if(window.FC$ && (FC$.TypeRWD==TipoRWDPlugins))vexLoad();});

  var IdiomaOT=4;
  function processLanguageResource(aResources){
    var MaxTextSize=1024;
    if(typeof oResources!="undefined"){
      var bSimples=(!Array.isArray(aResources[0]));
      if(bSimples)var iResources=1;
      else var iResources=aResources.length;
      var aItem,sKey,sValue;
      for(var i=0;i<iResources;i++){
        if(bSimples)aItem=aResources;else aItem=aResources[i];
        if(Array.isArray(aItem)){
          if(aItem.length>IdiomaOT){
            sKey=aItem[IdiomaOT];
            if(sKey!=""){
              sValue=oResources[sKey];
              if(sValue || sValue==""){
                if(bSimples)aResources[FC$.Language]=sValue.slice(0,MaxTextSize);
                else aResources[i][FC$.Language]=sValue.slice(0,MaxTextSize);
              }
              else if(FC$.Language==IdiomaOT){
                if(bSimples)aResources[FC$.Language]="\/\/\/"+ sKey +"\\\\\\";
                else aResources[i][FC$.Language]="\/\/\/"+ sKey +"\\\\\\";
              }
            }
          }
        }
      }
    }
    else if(FC$.isTest)console.log("resource object not defined");
  }

  return{
    fnUseEHC:fnUseEHC,
    uk:uk,
    oSystemURLs:oSystemURLs,
    formatMoney:formatMoney,
    formatMoneyInt:formatMoneyInt,
    getDecimalSep:getDecimalSep,
    pQuery:pQuery,
    oCatMenu:oCatMenu,
    oDescriptor1Menu:oDescriptor1Menu,
    oDescriptor2Menu:oDescriptor2Menu,
    oDescriptor3Menu:oDescriptor3Menu,
    IsOldIE:IsOldIE,
    oFoundationJSON:oFoundationJSON,
    useLangResource:useLangResource,
    fnAjaxExecFC:fnAjaxExecFC,
    loadAsyncCSS:loadAsyncCSS,
    getLimits:getLimits,
    getScreenLimits:getScreenLimits,
    isOnScreen:isOnScreen,
    initLazyLoad:initLazyLoad,
    execLazyLoad:execLazyLoad,
    fadeIn:fadeIn,
    execWaveInterchange:execWaveInterchange,
    xOffsetScreenLimits:xOffsetScreenLimits,
    yOffsetScreenLimits:yOffsetScreenLimits,
    xMinShiftLazyLoad:xMinShiftLazyLoad,
    yMinShiftLazyLoad:yMinShiftLazyLoad,
    iMinTimerLazyLoad:iMinTimerLazyLoad,
    iMaxTimerLazyLoad:iMaxTimerLazyLoad,
    iFadeTimeLazyLoad:iFadeTimeLazyLoad,
    iFadeStepsLazyLoad:iFadeStepsLazyLoad,
    LazyLoadWaitImage:LazyLoadWaitImage,
    GetCookie:GetCookie,
    SetCookie:SetCookie,
    AddEvent:AddEvent,
    RemoveEvent:RemoveEvent,
    onReady:onReady,
    onLoaded:onLoaded,
    TipoRWDBootstrap:TipoRWDBootstrap,
    TipoRWDFoundation:TipoRWDFoundation,
    TipoRWDPlugins:TipoRWDPlugins,
    TipoRWDVex:TipoRWDVex,
    AlertRWD:AlertRWD,
    ofnAlertClosed:ofnAlertClosed,
    OpenRWD:OpenRWD,
    SelfCloseRWD:SelfCloseRWD,
    wHandler:wHandler,
    AppendGA:AppendGA,
    ShowBadgeFC:ShowBadgeFC,
    MirrorCartQty:MirrorCartQty,
    MirrorCartCupom:MirrorCartCupom,
    FormatPreco:FormatPreco,
    enlargeQtyInput:enlargeQtyInput,
    showPwdViewer:showPwdViewer,
    showPwdViewerDelayed:showPwdViewerDelayed,
    togglePwdView:togglePwdView,
    ConsultaObjetoCorreios:ConsultaObjetoCorreios,
    addFormConjBuy:addFormConjBuy,
    addConjBuyCartOnPage:addConjBuyCartOnPage,
    aBuyTogether:aBuyTogether,
    fnLoadScript:fnLoadScript,
    fnClientLogout:fnClientLogout,
    GetID:GetID,
    fnShowImgError:fnShowImgError,
    fnDontGo:fnDontGo,
    GlobalSigninUser:GlobalSigninUser,
    signinFacebook:signinFacebook,
    signinWithGoogle:signinWithGoogle,
    fnGetSuggestions:fnGetSuggestions,
    fnSuggestCallBack:fnSuggestCallBack,
    fnGetSearchURL:fnGetSearchURL,
    bDoneSuggestions:bDoneSuggestions,
    fnOrderTrack:fnOrderTrack,
    fnRecaptchaInit:fnRecaptchaInit,
    vexLoad:vexLoad,
    RecoverCart:RecoverCart,
    fnFBAddToCart:fnFBAddToCart,
    fnGoogleAddToCart:fnGoogleAddToCart,
    fnGetCurrency:fnGetCurrency,
    fnPinterestAddToCart:fnPinterestAddToCart,
    fnPinterestPageVisitProd:fnPinterestPageVisitProd,
    fnTikTokAddToCart:fnTikTokAddToCart,
    processLanguageResource:processLanguageResource
  }
})();

var WL$=(function(){

  function fnButtonAddToWishlist(idp){
    var IdiomaLoja=FC$.Language;
    var aXYZ=[];
    aXYZ[0]=["Adicionado na lista de desejos","Added to wishlist","A�adido a la lista de deseos","Adicionado na lista de desejos","wishlist-added-to-wishlist"];
    aXYZ[1]=["Adicionar na lista de desejos","Add to wishlist","A�adir a la lista de deseos","Adicionar na lista de desejos","wishlist-add-to-wishlist"];
    aXYZ[2]=["Produto adicionado na lista de desejos. Clique aqui para ir para a lista de desejos.","Product added to wishlist. Click here to go to the wishlist.","Producto a�adido a la lista de deseos. Haga clic aqu� para ir a la lista de deseos.","Produto adicionado na lista de desejos. Clique aqui para ir para a lista de desejos.","wishlist-product-added-to-wishlist"];
    aXYZ[3]=["Clique aqui para adicionar o produto na lista de desejos","Click here to add to wishlist","Haga clic aqu� para a�adir a la lista de deseos","Clique aqui para adicionar o produto na lista de desejos","wishlist-click-here-to-add-to-wishlist"];
    FCLib$.processLanguageResource(aXYZ);
    var oProdWL=document.getElementById("ProdWL"+ idp);
    if(oProdWL){
      var sCont="";
      if(fnAlreadyAdded(idp)){
        if(typeof FuncButtonAddToWL==="function")sCont=FuncButtonAddToWL(idp,true); /* modelo personalizado da loja atrav�s de fun��o (j� adicionado) */
        else{
          if(typeof iModWishlist=="undefined")sCont="<div onclick=\"top.location.href='"+ FCLib$.uk("url-account") +"?wishlist=1#Wishlist'\" class=\"FCWishlist1 FCWishlist1OK\" title='"+ aXYZ[2][IdiomaLoja] +"'><img src=\"/images/wishlist_on.svg\"><div>"+ aXYZ[0][IdiomaLoja] +"</div></div>"; /* modelo padr�o */
          else {
            if(iModWishlist==1)sCont="<a title='"+ aXYZ[2][IdiomaLoja] +"' href=\""+ FCLib$.uk("url-account") +"?wishlist=1#Wishlist\"><span class=\"icon-share-wishlist-on\"></span></a>"; /* modelo 1 */
            else if(iModWishlist==2)sCont="<span class=FCWishlistOK><a href=\""+ FCLib$.uk("url-account") +"?wishlist=1#Wishlist\">"+ aXYZ[0][IdiomaLoja] +"</a></span>"; /* modelo 2 */
          }
        }
      }
      else{
        if(typeof FuncButtonAddToWL==="function")sCont=FuncButtonAddToWL(idp,false); /* modelo personalizado da loja atrav�s de fun��o (n�o adicionado) */
        else{
          if(typeof iModWishlist=="undefined")sCont="<div onclick=\"WL$.fnAddToWishlist("+idp+")\" title='"+ aXYZ[3][IdiomaLoja] +"' class=\"FCWishlist1 FCWishlist1Add\"><img src=\"/images/wishlist_off.svg\"><div>"+ aXYZ[1][IdiomaLoja] +"</div></div>"; /* modelo padr�o */
          else {
            if(iModWishlist==1)sCont="<a href=\"#wl\" title='"+ aXYZ[3][IdiomaLoja] +"' onclick=\"WL$.fnAddToWishlist("+idp+")\" rel=\"nofollow\"><span class=\"icon-share-wishlist-off\"></span></a>"; /* modelo 1 */
            else if(iModWishlist==2)sCont="<span class=FCWishlistAdd><a onclick=\"WL$.fnAddToWishlist("+idp+")\" rel=\"nofollow\">"+ aXYZ[1][IdiomaLoja] +"</a>"; /* modelo 2 */
          }
        }
      }
      oProdWL.innerHTML=sCont;
    }
  }

  function fnAlreadyAdded(idp){
    var bFound=false;
    var i=0;
    if(FC$.ClientID>0){
      var sMyWishlist=localStorage.getItem("myWishlist"+FC$.ClientID);
      if(sMyWishlist){
        var oItems=sMyWishlist.split(",");
        var iTamItems=oItems.length;
        while(i<iTamItems && !bFound){
          if(oItems[i]==idp){bFound=true;}
          else{i++;}
        }
      }
    }
    return(bFound);
  }

  function fnAddToWishlist(idp){
    var IdiomaLoja=FC$.Language;
    var aXYZ=[];
    aXYZ[0]=["Voc� precisa estar logado para adicionar na sua lista de desejos.\n\n Deseja fazer login?","You must be logged in to add to your wish list. Do you want to log in?","Debe iniciar sesi�n para agregarlo a su lista de deseos. �Quieres iniciar sesi�n?","Voc� precisa estar logado para adicionar a sua lista de desejos. Deseja fazer login?","wishlist-login-alert"];
    if(FC$.ClientID==0 || FC$.ClientID==-1){
      FCLib$.processLanguageResource(aXYZ);
      if(confirm(aXYZ[0][IdiomaLoja])){top.location.href=FCLib$.uk("url-register") +"?pp=1&"+ (FCLib$.fnUseEHC()?"productid":"idproduto") +"="+idp;}   
    }
    else FCLib$.fnAjaxExecFC(FCLib$.uk("url-json-wishlist"),"c=1&idp="+idp,true,fnCallbackWishlistAdd,idp);
  }
  
  function fnCallbackWishlistAdd(obj,idp){
    try{var oJSON=JSON.parse(obj.responseText);}catch(e){var oJSON=null;}
    if(oJSON){
      var oErr=oJSON.err;
      if(oErr=="OK"){
        console.log("Product "+ idp +" inserted in wishlist");
        if(typeof gtag!='undefined' && FC$.GA){
          gtag("event","add_to_wishlist",{currency:FCLib$.fnGetCurrency(),items:[{item_id:idp,quantity:1}]});
        }
        fnRefreshLocalStorage(idp);
      }else{
        console.log(oErr);
        var oCode=oJSON.code;
        if(oCode==6)alert(oErr);
      }
    }else{console.log("JSON error")}
  }

  function fnRefreshLocalStorage(idp){
    FCLib$.fnAjaxExecFC(FCLib$.uk("url-json-wishlist"),"c=3",true,fnCallbackWishlistRefreshLocStorage,idp);
  }

  function fnCallbackWishlistRefreshLocStorage(obj,idp){
    if(FC$.ClientID>0){
      try{var oJSON=JSON.parse(obj.responseText);}catch(e){var oJSON=null;}
      if(oJSON){
        var oErr=oJSON.err;
        if(oErr=="OK"){
          var oIds=oJSON.ids;
          localStorage.setItem("myWishlist"+FC$.ClientID,oIds);
        }else{console.log("Localstore not updated")}     
      }else{console.log("JSON error")}
      if(idp)fnButtonAddToWishlist(idp);
    }
  }

  function fnChangeDateExp(iSel){
    FCLib$.fnAjaxExecFC(FCLib$.uk("url-json-wishlist"),"c=5&sel="+iSel,true,fnCallbackWishlistChangeDateExp);
  }

  function fnCallbackWishlistChangeDateExp(obj){
    var oTxtCopyFC=document.getElementById("idTxtCopyFC");   
    if(oTxtCopyFC)try{oTxtCopyFC.remove();}catch(e){} 
    try{var oJSON=JSON.parse(obj.responseText);}catch(e){var oJSON=null;}
    if(oJSON){
      var oErr=oJSON.err;
      if(oErr=="OK"){
        var sTkn=oJSON.tkn;
        if(sTkn!=""){
          var oLinkShare=document.getElementById("FCLinkShareWL");
          if(oLinkShare){
            var sLink=oLinkShare.value;
            var iPos=sLink.indexOf("=");
            sLink=sLink.substring(0,iPos+1)+sTkn;
            oLinkShare.value=sLink;
          }
        }
      }else{console.log(oErr)}     
    }else{console.log("JSON error")}
  }
  
  function fnShare(iSite,sTxt,sPar){
    var oLinkShare=document.getElementById("FCLinkShareWL");
    if(oLinkShare){
      var sLink="";
      var sLinkShare=oLinkShare.value;
      if(iSite==1){sLink="https://twitter.com/share?url="+ escape(sLinkShare) + sPar +"&text="+ escape(sTxt) +"&related=fastcommercebr:"+ escape("This store uses Fastcommerce.")}
      else if(iSite==2){sLink="https://www.facebook.com/share.php?u="+ sLinkShare}
      else if(iSite==3){sLink="https://plus.google.com/share?hl=pt-BR&amp;url="+ sLinkShare}
      else if(iSite==4){
        if(FC$.Mobile || document.documentElement.clientWidth<400){sLink="whatsapp://send?text="+ sTxt + sLinkShare}
        else{sLink="https://web.whatsapp.com/send?text="+ escape(sTxt) + escape(sLinkShare)}
      }
      if(sLink!="")window.open(sLink);
    }
  }

  function fnInsertAfter(newNode, referenceNode) {
    referenceNode.parentNode.insertBefore(newNode, referenceNode.nextSibling);
  }

  function fnCopy(obj){
    var IdiomaLoja=FC$.Language;
    var aXYZ=[];
    aXYZ[0]=["Link copiado para a �rea de transfer�ncia. Use CTRL+V para colar.","Link copied to clipboard. Use CTRL+V to paste.","Enlace copiado","Link copiado para a �rea de transfer�ncia. Use CTRL+V para colar.","wishlist-link-copied-to-clipboard"];
    obj.select();
    document.execCommand('copy');
    var oTxtCopyFC=document.getElementById("idTxtCopyFC");
    if(!oTxtCopyFC){
      var oNewElement=document.createElement("div");
      oNewElement.setAttribute("id","idTxtCopyFC"); 
      FCLib$.processLanguageResource(aXYZ);
      oNewElement.innerHTML=aXYZ[0][IdiomaLoja];
      fnInsertAfter(oNewElement,obj)
    }
  }

  return{
    fnButtonAddToWishlist:fnButtonAddToWishlist,
    fnAddToWishlist:fnAddToWishlist,
    fnRefreshLocalStorage:fnRefreshLocalStorage,
    fnChangeDateExp:fnChangeDateExp,
    fnShare:fnShare,
    fnCopy:fnCopy
  }
})();

function ToggleIDs(id1,id2){
  document.getElementById(id1).style.display='';
  document.getElementById(id2).style.display='none';
}

function ReadXMLNode(obj,sNode){try{return obj.getElementsByTagName(sNode)[0].firstChild.data;}catch(e){return null;}}

function AjaxExecFC(file,sParams,IsPOST,processXML,param1,param2,param3){
  sParams=sParams.replace(/ /g,"+");
  var xmlObj=null;
  if(window.XMLHttpRequest){xmlObj=new XMLHttpRequest();}
  else if(window.ActiveXObject){xmlObj=new ActiveXObject("Microsoft.XMLHTTP");} 
  else{return;}
  xmlObj.onreadystatechange=function(){if(xmlObj.readyState==4){processXML(xmlObj.responseXML,param1,param2,param3);}};
  if(IsPOST){
    xmlObj.open('POST',file,true);
    xmlObj.setRequestHeader("Content-type","application/x-www-form-urlencoded");
    xmlObj.send(sParams);
  }
  else{
    xmlObj.open('GET',file+'?'+sParams,true);
    xmlObj.send('');
  }
}

function AddProdCartOnPage(IDLoja,IDProd,FormNum,este){
  if(IDProd==0)var sParamsProd=CartProdArrays();
  else var sParamsProd=CartProd(IDProd,FormNum);
  AjaxExecFC(FCLib$.uk("url-add-multiple-products"),"xml=1"+sParamsProd,true,processXMLAddMult,IDLoja,este,sParamsProd);
}

function processXMLAddMult(obj,IDLoja,este,sParamsProd){
  try{var iErr=obj.getElementsByTagName("err")[0].firstChild.data;}catch(e){return;}
  try{var sMsg=obj.getElementsByTagName("msg")[0].firstChild.data;}catch(e){return;}
  if(iErr=="0"){
    try{var sCartText=obj.getElementsByTagName("CartText")[0].firstChild.data;}catch(e){var sCartText="";}
    try{var sCheckoutText=obj.getElementsByTagName("CheckoutText")[0].firstChild.data;}catch(e){var sCheckoutText="";}
  }
  else{
    var sCartText="";
    var sCheckoutText="";
  }
  if(typeof gtag!='undefined'){ 
    var sURL_Analytics=FCLib$.uk("url-add-multiple-products") +"?dmb=1"+ sParamsProd;
    gtag('event', 'page_view', {'send_to': FC$.GA,'page_path':sURL_Analytics});
  }
  else if(typeof ga!=='undefined'){
    var sURL_Analytics=FCLib$.uk("url-add-multiple-products") +"?dmb=2"+ sParamsProd;
    ga('send', 'pageview',sURL_Analytics);
  }
  else if(typeof _gaq!='undefined'){ 
    var sURL_Analytics=FCLib$.uk("url-add-multiple-products") +"?dmb=3"+ sParamsProd;
    _gaq.push(['_trackPageview',sURL_Analytics]);
  }
  /* Google Tag Manager */
  if(typeof dataLayerGTM!=='undefined'){
    var sURL_GTM=FCLib$.uk("url-add-multiple-products") +"?dmb=4"+ sParamsProd;
    dataLayerGTM.push({
      'event': 'VirtualPageview',
      'eventName': 'addToCart',
      'eventTitle': document.title,
      'urlPage': sURL_GTM
    });
  }
  try{ShowCartOnPage(IDLoja,iErr,sMsg,sCartText,sCheckoutText,este);}
  catch(e){
    ShowCartOnPageFC(IDLoja,iErr,sMsg,sCartText,sCheckoutText,este);
    try{FuncCartOnPage(IDLoja,iErr,sMsg,sCartText,sCheckoutText,este);}catch(e){}
  }
}

function CartProdArrays(){
  var aProdID=new Array();
  var aProdQt=new Array();
  var aAdicional1=new Array();
  var aAdicional2=new Array();
  var aAdicional3=new Array();
  var aAdicionalD1=new Array();
  var aAdicionalD2=new Array();
  var aAdicionalD3=new Array();
  var aCor=new Array();
  var oForm=document.FormMult;
  var aInputs=oForm.getElementsByTagName("input");
  iProds=0;
  for(var i=0;i<aInputs.length;i++){
    if(aInputs[i].id.substr(0,12)=="idQTIncMult_"){
      sProdQt=aInputs[i].value;
      if(sProdQt!="0"){
        aProdID[iProds]=(aInputs[i].id.substring(12));
        aProdQt[iProds]=sProdQt;
        aAdicional1[iProds]=GetMultAdicProd("Adicional1",aProdID[iProds]);
        aAdicional2[iProds]=GetMultAdicProd("Adicional2",aProdID[iProds]);
        aAdicional3[iProds]=GetMultAdicProd("Adicional3",aProdID[iProds]);
        aAdicionalD1[iProds]=GetMultAdicProd("AdicionalD1",aProdID[iProds]);
        aAdicionalD2[iProds]=GetMultAdicProd("AdicionalD2",aProdID[iProds]);
        aAdicionalD3[iProds]=GetMultAdicProd("AdicionalD3",aProdID[iProds]);
        aCor[iProds]=GetMultAdicProd("Cor",aProdID[iProds]);
        iProds++;
      }
    }
  }
  var sParams="";
  for(var i=0;i<aProdID.length;i++){
    sParams+="&QTIncMult_"+ aProdID[i] +"="+ aProdQt[i];
    if(aAdicional1[i]!='')sParams+="&Adicional1_"+ aProdID[i] +"="+ EncodeParamFC(aAdicional1[i]);
    if(aAdicional2[i]!='')sParams+="&Adicional2_"+ aProdID[i] +"="+ EncodeParamFC(aAdicional2[i]);
    if(aAdicional3[i]!='')sParams+="&Adicional3_"+ aProdID[i] +"="+ EncodeParamFC(aAdicional3[i]);
    if(aAdicionalD1[i]!='')sParams+="&AdicionalD1_"+ aProdID[i] +"="+ EncodeParamFC(aAdicionalD1[i]);
    if(aAdicionalD2[i]!='')sParams+="&AdicionalD2_"+ aProdID[i] +"="+ EncodeParamFC(aAdicionalD2[i]);
    if(aAdicionalD3[i]!='')sParams+="&AdicionalD3_"+ aProdID[i] +"="+ EncodeParamFC(aAdicionalD3[i]);
    if(aCor[i]!='')sParams+="&Cor_"+ aProdID[i] +"="+ EncodeParamFC(aCor[i]);
  }
  return sParams;
}

function GetMultAdicProd(sAdicName,IDProd){
  var oValue=eval("document.FormMult."+sAdicName+"_"+IDProd);
  if(oValue==undefined)var sValue=undefined; else var sValue=oValue.value;
  if(sValue==undefined || sValue=="-") return ""; else return sValue;
}

function CartProd(ProdID,FormNum){
  if(FormNum==0)var oForm=eval("Form"+ProdID);
  else var oForm=eval("FCForm"+FormNum);
  if(oForm==undefined)Adicional1=Adicional2=Adicional3=AdicionalD1=AdicionalD2=AdicionalD3=Cor="";
  else{
    Adicional1=GetAdicProd("Adicional1",oForm);
    Adicional2=GetAdicProd("Adicional2",oForm);
    Adicional3=GetAdicProd("Adicional3",oForm);
    AdicionalD1=GetAdicProd("AdicionalD1",oForm);
    AdicionalD2=GetAdicProd("AdicionalD2",oForm);
    AdicionalD3=GetAdicProd("AdicionalD3",oForm);
    Cor=GetAdicProd("Cor",oForm);
  }
  var sParams="";
  sParams+="&QTIncMult_"+ ProdID +"=1";
  if(Adicional1!='')sParams+="&Adicional1_"+ ProdID +"="+ EncodeParamFC(Adicional1);
  if(Adicional2!='')sParams+="&Adicional2_"+ ProdID +"="+ EncodeParamFC(Adicional2);
  if(Adicional3!='')sParams+="&Adicional3_"+ ProdID +"="+ EncodeParamFC(Adicional3);
  if(AdicionalD1!='')sParams+="&AdicionalD1_"+ ProdID +"="+ EncodeParamFC(AdicionalD1);
  if(AdicionalD2!='')sParams+="&AdicionalD2_"+ ProdID +"="+ EncodeParamFC(AdicionalD2);
  if(AdicionalD3!='')sParams+="&AdicionalD3_"+ ProdID +"="+ EncodeParamFC(AdicionalD3);
  if(Cor!='')sParams+="&Cor_"+ ProdID +"="+ EncodeParamFC(Cor);
  return sParams;
}

function EncodeParamFC(value){return escape(value).replace(/\+/g,"%2B");}

function GetAdicProd(sAdicName,oForm){
  var oValue=eval("oForm."+sAdicName);
  if(oValue==undefined)var sValue=undefined; else var sValue=oValue.value;
  if(sValue==undefined || sValue=="-") return ""; else return sValue;
}

function PrepareTextUA(sText){
  return sText.replace(/[^a-z0-9������������������������������"".+]/gi,'+').replace(/\+\+/g,'+');
}

function MostraImgOnError(este,iIdioma){
  if(ImgOnError==undefined || ImgOnError=="nd")ImgOnError="/images/nd";
  if(ImgOnError.length-ImgOnError.lastIndexOf(".")==4)este.src=ImgOnError;
  else este.src=ImgOnError+iIdioma+".gif";
}

function MostraImgOnErrorShim(este){
  este.src="/images/shim.gif?cccfc=1";
}

function PutObject(IDMenu,IDPos){
  var oPos=getPos(document.getElementById(IDPos));
  var oMenu=document.getElementById(IDMenu);
  oMenu.style.visibility='visible';
  oMenu.style.left=oPos.x;
  oMenu.style.top=oPos.y;
}

function getPos(obj){
  var output=new Object();var mytop=0,myleft=0;
  while(obj){mytop+=obj.offsetTop;myleft+=obj.offsetLeft;obj=obj.offsetParent;}
  output.x=myleft;output.y=mytop;
  return output;
}

function CatToggle(id){
  ul="ul_"+id;
  img="img_"+id;
  ulElement=document.getElementById(ul);
  imgElement=document.getElementById(img);
  if(ulElement){
    if (ulElement.className=="CatClosed"){
      ulElement.className="CatOpened";
      imgElement.className="ImgOpened";
    }
    else{
      ulElement.className="CatClosed";
      imgElement.className="ImgClosed";
    }
  }
}

function OpenCat(id){
  if(document.getElementById(id))OpenCat(document.getElementById(id).parentNode.id.substring(3));
  ul="ul_"+id;
  img="img_"+id;
  ulElement=document.getElementById(ul);
  imgElement=document.getElementById(img);
  if(ulElement){
      ulElement.className="CatOpened";
      imgElement.className="ImgOpened";
  }
}

function CloseCat(oCat){
  var oUL=oCat.getElementsByTagName("ul");
  for(var i=0;i<oUL.length;i++){
    oUL[i].className="CatClosed";
    imgElement=document.getElementById(oUL[i].id.replace("ul_","img_"));
    if(imgElement)imgElement.className="ImgClosed";
  }
}

function GetIDCatFromURL(SepIni,SepFim){
  var IDCatURL=0;
  var sPag=document.location.href.toUpperCase();
  var sParamCat='IDCATEGORIA';
  var PosIDCatIni=sPag.indexOf(sParamCat+SepFim);
  if(PosIDCatIni<0){var sParamCat='IDCATEGORY';var PosIDCatIni=sPag.indexOf(sParamCat+SepFim);}
  if(PosIDCatIni>=0){
    PosIDCatIni=PosIDCatIni+sParamCat.length+1;
    IDCatURL=sPag.substring(PosIDCatIni);
    var PosIDCatFim=IDCatURL.indexOf(SepIni);
    if(PosIDCatFim>=0)IDCatURL=IDCatURL.substr(0,PosIDCatFim);
  }
  return IDCatURL;
}

function DefineCatsOut(IDCategoriaAtualFC,iOut,SpanCat){
  var ULsFC=SpanCat.getElementsByTagName('ul');
  for(var i=0;i<ULsFC.length;i++){
    if(ULsFC[i].className.toUpperCase()=='CATCLOSED'||ULsFC[i].className.toUpperCase()=='CATOPENED'){
      var LIsFC=ULsFC[i].getElementsByTagName('li');
      var j=0;
      var AcheiCat=false;
      while(j<LIsFC.length && !AcheiCat){
        if(LIsFC[j].id.indexOf('_'+IDCategoriaAtualFC)>0){
          AcheiCat=true;
          ULsFC[i].className='CatOpened';
          var AsFC=LIsFC[j].getElementsByTagName('a')[0];
          AsFC.className='PathCatActive';
          OpenCat(LIsFC[j].id);
        }
        else{j++;}
      }
      if(iOut==11)for(var j=0;j<LIsFC.length;j++)if(LIsFC[j].id.indexOf('_'+IDCategoriaNivel0FC)<0 && LIsFC[j].parentNode.id.substring(0,9)=='idMenuCat')LIsFC[j].className="CatClosed";
      if(iOut==10)for(var j=0;j<LIsFC.length;j++)if(LIsFC[j].id.indexOf('_'+IDCategoriaNivel0FC)<0 && LIsFC[j].parentNode.id.substring(0,9)=='idMenuCat')CloseCat(LIsFC[j]);
    }
  }
}

function DefineCatDefault(IDCategoriaAtualFC){
  if(IDCategoriaAtualFC==0)IDCategoriaAtualFC=GetIDCatFromURL("&","=");
  if(IDCategoriaAtualFC==0)IDCategoriaAtualFC=GetIDCatFromURL(",",",");
  if(IDCategoriaAtualFC>0){
    var SelectsFC=document.getElementsByTagName('select');
    for(var i=0;i<SelectsFC.length;i++){
      if(SelectsFC[i].name.substr(0,9).toUpperCase()=='IDCATEGOR'){
        var j=0;
        var AcheiCat=false;
        while(j<SelectsFC[i].length && !AcheiCat){
          if(SelectsFC[i].options[j].value==IDCategoriaAtualFC){
            AcheiCat=true;
            SelectsFC[i].options[j].selected=true;
          }
          else{j++;}
        }
      }
    }
    var SpansFC=document.getElementsByTagName('span');
    for(var i=0;i<SpansFC.length;i++){
      var sClass=SpansFC[i].className;
      if(sClass=='EstListCat2')var iOut=2;
      else if(sClass=='EstListCat10')var iOut=10;
      else if(sClass=='EstListCat11')var iOut=11;
      else if(sClass=='EstListCat12')var iOut=12;
      else var iOut=0;
      if(iOut==12 && IDCategoriaNivel0FC!=0)DefineCatsOut(IDCategoriaNivel0FC,iOut,SpansFC[i]);
      else if(iOut!=0)DefineCatsOut(IDCategoriaAtualFC,iOut,SpansFC[i]);
      }
  }
}

function VerificaCofre(este){
  if(este.value==0)document.getElementById('btDelCofre').style.display='none';
  else document.getElementById('btDelCofre').style.display='';
  AlteraExibicaoDadosCartao(este.value==0);
}

function ExcCofre(IDLoja){
  var oSelCofre=document.Form1.idSelectCofreFC;
  if(oSelCofre.selectedIndex>0){
    IFExcCofre.location.href=FCLib$.uk("url-delete-from-safe") +'?IndexCofre='+oSelCofre[oSelCofre.selectedIndex].value;
  }
}

function AlteraExibicaoDadosCartao(bExibe){
  var sDisplay='';
  if(!bExibe){sDisplay='none';}
  var oTRccNumFC=document.getElementById('idTRccNumFC');if(oTRccNumFC)oTRccNumFC.style.display=sDisplay;
  var oTRccExpFC=document.getElementById('idTRccExpFC');if(oTRccExpFC)oTRccExpFC.style.display=sDisplay;
  var oTRccNomeFC=document.getElementById('idTRccNomeFC');if(oTRccNomeFC)oTRccNomeFC.style.display=sDisplay;
  var oTRTitularCPFFC=document.getElementById('idTRTitularCPFFC');if(oTRTitularCPFFC)oTRTitularCPFFC.style.display=sDisplay;
  var oTRTitularNascFC=document.getElementById('idTRTitularNascFC');if(oTRTitularNascFC)oTRTitularNascFC.style.display=sDisplay;
  var oTRTitularFoneFC=document.getElementById('idTRTitularFoneFC');if(oTRTitularFoneFC)oTRTitularFoneFC.style.display=sDisplay;
  var oTRGuardaCartaoFC=document.getElementById('idTRGuardaCartaoFC');if(oTRGuardaCartaoFC)oTRGuardaCartaoFC.style.display=sDisplay;
  var oPagtoJUT=document.getElementById('idPagtoJUTFC');if(oPagtoJUT){var oTRccSegFC=document.getElementById('idTRccSegFC');if(oTRccSegFC)oTRccSegFC.style.display=sDisplay;}
  var oPagtoBC=document.getElementById('idPagtoBCFC');if(oPagtoBC){var oTRccSegFC=document.getElementById('idTRccSegFC');if(oTRccSegFC)oTRccSegFC.style.display=sDisplay;}
}

function AddURLServices(){
  var sPag=document.location.href;
  document.write("<style>.BookmarkSites{font-size:9px;font-family:verdana;}.BookmarkSites a:link{color:#000000;text-decoration:none}.BookmarkSites a:hover{color:#FF0000;text-decoration:none}.BookmarkSites ul{list-style:none;margin-top:0px;margin-left:0px;padding:0}.BookmarkSites ul li{display:inline;margin-left:10px}.BookmarkSites img{width:12px;height:12px;position:relative;top:2px;left:2px;margin: 0px 5px 0px 0px;padding:2px 2px 0px 5px;border-style:none}</style>");
  document.write("<div class=BookmarkSites><ul>");
  document.write("<li><a target=_blank href=http://digg.com/submit?phase=2&url="+ sPag +"><img src=/images/IcDigg.gif?cccfc=1>Digg it</a></li>");
  document.write("<li><a target=_blank href=http://delicious.com/post?url="+ sPag +"><img src=/images/IcDelicious.gif?cccfc=1>Delicious</a></li>");
  document.write("<li><a target=_blank href=http://twitter.com/home?status="+ escape(document.title) +"+"+ sPag +"><img src=/images/IcTwitter.gif?cccfc=1>Twitter</a></li>");
  document.write("<li><a target=_blank href=http://reddit.com/submit?url="+ sPag +"><img src=/images/IcReddit.gif?cccfc=1>Reddit</a></li>");
  document.write("<li><a target=_blank href=http://google.com/bookmarks/mark?op=edit&amp;bkmk="+ sPag +"><img src=/images/IcGoogleBook.gif?cccfc=1>Google bookmarks</a></li>");
  document.write("<li><a target=_blank href=http://furl.net/storeIt.jsp?u="+ sPag +"><img src=/images/IcFurl.gif?cccfc=1>Furl</a></li>");
  document.write("</ul></div>");
}

function ChangeCBIncMult(este,QTField){
  if(este.checked && QTField.value=='0'){try{QTField.value='1';QTField.focus();QTField.select();}catch(e){}}
  if(!este.checked){QTField.value='0';}
}

function ChangeQTIncMult(este,CBField){
  if(este.value=='0'){CBField.checked=false;}
  else{CBField.checked=true;}
}

function FocusQTIncMult(este,CBField){
  CBField.checked=true;
  if(este.value=='0')este.select();
}

function NumFilt(evt){
  if(sBrowser=='IE'){var charCode=event.keyCode;}else{var charCode=evt.which;}
  if(charCode!=0 && charCode!=8 && (charCode<48||charCode>57)){return false;}else{return true;}
}

function ValidaOpcao(oCombo,sCombo,iIdioma){
  if(oCombo.selectedIndex==0){
    var XYZ=["Selecione ","Select ","Seleccione ","Seleccione ","option-select"];
    FCLib$.processLanguageResource(XYZ);
    alert(XYZ[FC$.Language] + sCombo +".");
    oCombo.focus();
    return false;
    }
  else{return true;}
}

function ValidaMult(oQT,oCombo,sCombo,iIdioma){
  try{
    if(oQT.value=='0')return true;
    if(oCombo.selectedIndex==0){
      var XYZ=["Selecione ","Select ","Seleccione ","Seleccione ","option-select-mult"];
      FCLib$.processLanguageResource(XYZ);
      alert(XYZ[FC$.Language] + sCombo +".");
      oCombo.focus();
      return false;
      }
    else{return true;}
  }catch(e){return true;}
}


function MostraDisp(IDLoja,IDProduto){
  if(FC$.TypeRWD==FCLib$.TipoRWDPlugins || FC$.TypeRWD==FCLib$.TipoRWDVex){
    popup=FCLib$.OpenRWD(FCLib$.uk("url-product-availability") + IDProduto,"Disp","width=400,height=600");
  }
  else{
    popup=window.open(FCLib$.uk("url-product-availability") + IDProduto,"Disp","top=10,left=10,height=320,width=400,scrollbars=auto");
  }
  if(FC$.TypeRWD!=FCLib$.TipoRWDVex)popup.focus();
  return void(0);
}

function MostraDispCaptcha(IDLoja,IDProduto){
  if(FC$.TypeRWD==FCLib$.TipoRWDPlugins || FC$.TypeRWD==FCLib$.TipoRWDVex){
    popup=FCLib$.OpenRWD(FCLib$.uk("url-product-availability") + IDProduto,"Disp","width=400,height=700");
  }
  else{
    popup=window.open(FCLib$.uk("url-product-availability") + IDProduto,"Disp","top=10,left=10,height=370,width=400,scrollbars=auto");
  }
  if(FC$.TypeRWD!=FCLib$.TipoRWDVex)popup.focus();
  return void(0);
}

function MostraDispIf(IDLoja,IDProduto,NomeLoja){
  windowopen(NomeLoja,FCLib$.uk("url-product-availability") + IDProduto +"&if=1",10,10,400,320);
}
function MostraDispIfCaptcha(IDLoja,IDProduto,NomeLoja){
  windowopen(NomeLoja,FCLib$.uk("url-product-availability") + IDProduto +"&if=1",10,10,400,370);
}

function MostraIndique(IDLoja,IDProduto){
  if(FC$.TypeRWD==FCLib$.TipoRWDPlugins || FC$.TypeRWD==FCLib$.TipoRWDVex){
    popup=FCLib$.OpenRWD(FCLib$.uk("url-product-recommend") + IDProduto,"Indique","width=423,height=700");
  }
  else{
    popup=window.open(FCLib$.uk("url-product-recommend") + IDProduto,"Indique","top=10,left=10,height=420,width=423,scrollbars=auto");
  }
  if(FC$.TypeRWD!=FCLib$.TipoRWDVex)popup.focus();
  return void(0);
}

function MostraIndiqueCaptcha(IDLoja,IDProduto){
  if(FC$.TypeRWD==FCLib$.TipoRWDPlugins || FC$.TypeRWD==FCLib$.TipoRWDVex){
    popup=FCLib$.OpenRWD(FCLib$.uk("url-product-recommend") + IDProduto,"Indique","width=423,height=700");
  }
  else{
    popup=window.open(FCLib$.uk("url-product-recommend") + IDProduto,"Indique","top=20,left=20,height=450,width=420,scrollbars=auto");
  }
  if(FC$.TypeRWD!=FCLib$.TipoRWDVex)popup.focus();
  return void(0);
}

function MostraIndiqueIf(IDLoja,IDProduto,NomeLoja){
  windowopen(NomeLoja,FCLib$.uk("url-product-recommend") + IDProduto +"&if=1",10,10,423,420);
}
function MostraIndiqueIfCaptcha(IDLoja,IDProduto,NomeLoja){
  windowopen(NomeLoja,FCLib$.uk("url-product-recommend") + IDProduto +"&if=1",10,10,423,470);
}

function ValidaEmail(sEmail) {
  var regex=/^[a-zA-Z0-9._-]+@([a-zA-Z0-9.-]+\.)+[a-zA-Z0-9.-]{2,20}$/;
  return regex.test(sEmail);
}

function ValidaCEP(campo) {
  var regex=/^([0-9]){5}([-]?)([0-9]){3}$/;
  return regex.test(campo);
}
 
function ValidaForcaSenha(){
  var TextoSenhaMin=document.getElementById('idTxtSenhaMinOriFC');
  var strength=document.getElementById('idTxtForcaSenhaFC');
  var pwd=document.getElementById("P2SenhaCli");
  if(pwd.value.length<6){
    TextoSenhaMin.style.display="";
    strength.style.display="none";
    return void(0);
  }
  else {
    TextoSenhaMin.style.display="none";
    strength.style.display="";
    var strengthResult=document.getElementById('idTxtResultForcaSenhaFC');
    var strongRegex=new RegExp("^(?=.{8,})(?=.*[A-Z])(?=.*[a-z])(?=.*[0-9])(?=.*\\W).*$", "g");
    var mediumRegex=new RegExp("^(?=.{7,})(((?=.*[A-Z])(?=.*[a-z]))|((?=.*[A-Z])(?=.*[0-9]))|((?=.*[a-z])(?=.*[0-9]))).*$", "g");
    var enoughRegex=new RegExp("(?=.{3,}).*", "g");
    if(strongRegex.test(pwd.value)){
     document.getElementById('idResult1TxtForcaSenhaFC').style.display="none";
     document.getElementById('idResult1ImgForcaSenhaFC').style.display="none";
     document.getElementById('idResult2TxtForcaSenhaFC').style.display="none";
     document.getElementById('idResult2ImgForcaSenhaFC').style.display="none";
     document.getElementById('idResult3TxtForcaSenhaFC').style.display="";
     document.getElementById('idResult3ImgForcaSenhaFC').style.display=""; 
    }
    else if(mediumRegex.test(pwd.value)){
     document.getElementById('idResult1TxtForcaSenhaFC').style.display="none";
     document.getElementById('idResult1ImgForcaSenhaFC').style.display="none";
     document.getElementById('idResult2TxtForcaSenhaFC').style.display="";
     document.getElementById('idResult2ImgForcaSenhaFC').style.display="";
     document.getElementById('idResult3TxtForcaSenhaFC').style.display="none";
     document.getElementById('idResult3ImgForcaSenhaFC').style.display="none";
    }
    else{
     document.getElementById('idResult1TxtForcaSenhaFC').style.display="";
     document.getElementById('idResult1ImgForcaSenhaFC').style.display="";
     document.getElementById('idResult2TxtForcaSenhaFC').style.display="none";
     document.getElementById('idResult2ImgForcaSenhaFC').style.display="none";
     document.getElementById('idResult3TxtForcaSenhaFC').style.display="none";
     document.getElementById('idResult3ImgForcaSenhaFC').style.display="none";
    }
  }
}

function LimitaTexto(CampoTexto,MaxChars,iIdioma){
  if(CampoTexto.value.length>MaxChars){
    CampoTexto.value=CampoTexto.value.substring(0,MaxChars);
    var aXYZ=[];
    aXYZ[0]=["Este campo pode conter at� ","Maximum capacity is ","Este campo puede contener hasta ","Este campo pode conter at� ","text-maximum-capacity"];
    aXYZ[1]=[" caracteres."," characters."," caracteres."," caracteres.","text-maximum-capacity-characters"];
    FCLib$.processLanguageResource(aXYZ);
    alert(aXYZ[0][FC$.Language] + MaxChars + aXYZ[1][FC$.Language]);
    CampoTexto.focus();
    }
}

function FormatPrecoReais(num){
  num=num.toString().replace(/\$|\,/g,'');
  if(isNaN(num))num="0";
  sign=(num==(num=Math.abs(num)));
  num=Math.floor(num*100+0.50000000001);
  cents=num%100;
  num=Math.floor(num/100).toString();
  if(cents<10)cents="0"+cents;
  for(var i=0;i<Math.floor((num.length-(1+i))/3);i++)num=num.substring(0,num.length-(4*i+3))+'.'+num.substring(num.length-(4*i+3));
  return ((sign)?'':'-')+'R$&nbsp;'+num+','+cents;
}

function FormatPrice(num,symbol){
  num=num.toString().replace(/\$|\,/g,'');
  if(isNaN(num))num="0";
  sign=(num==(num=Math.abs(num)));
  num=Math.floor(num*100+0.50000000001);
  cents=num%100;
  num=Math.floor(num/100).toString();
  if(cents<10)cents="0"+cents;
  for(var i=0;i<Math.floor((num.length-(1+i))/3);i++)num=num.substring(0,num.length-(4*i+3))+'.'+num.substring(num.length-(4*i+3));
  return ((sign)?'':'-')+symbol+'&nbsp;'+num+','+cents;
}

function CalculaParcelaJurosCompostos(Preco,Parcelas){
  if(Juros[Parcelas-1]==0)return Preco/Parcelas;
  else return Math.round(Preco*(Math.pow(1+Juros[Parcelas-1]/100,Parcelas)*Juros[Parcelas-1]/100)/(Math.pow(1+Juros[Parcelas-1]/100,Parcelas)-1)*100)/100;
}

function CalculateInstallment(Price,Parcels){
  if(ParcelsInterests[Parcels-1]==0)return Price/Parcels;
  else return Math.round(Price*(Math.pow(1+ParcelsInterests[Parcels-1]/100,Parcels)*ParcelsInterests[Parcels-1]/100)/(Math.pow(1+ParcelsInterests[Parcels-1]/100,Parcels)-1)*100)/100;
}

function MostraPesquisaCEP(){popup=window.open('https://buscacepinter.correios.com.br/app/endereco/index.php','PesquisaCEP','top=30,left=1,height=550,width=790,menubar=yes,location=yes,toolbar=yes,scrollbars=yes,resizable=yes');popup.focus();return void(0);}


var DIF_dragging=false;
var DIF_iframeBeingDragged="";
var DIF_iframeObjects=new Object();
var DIF_iframeWindows=new Object();
var DIF_iframeMouseDownLeft=new Object();
var DIF_iframeMouseDownTop=new Object();
var DIF_pageMouseDownLeft=new Object();
var DIF_pageMouseDownTop=new Object();
var DIF_handles=new Object();
var DIF_highestZIndex=210;
var DIF_raiseSelectedIframe=false;
var DIF_allowDragOffScreen=false;

bringSelectedIframeToTop(true);

function bringSelectedIframeToTop(val){DIF_raiseSelectedIframe=val;}

function allowDragOffScreen(val){DIF_allowDragOffScreen=val;}

function addHandle(o,win){
  if(arguments.length==2 && win==window){
    var p=win;
    while(p=p.parent){
      if(p.addHandle){p.addHandle(o,win,true);return;}
      if(p==win.top){return;}
      }
    return;
  }
  var topRef=win;
  var topRefStr="window";
  while(topRef.parent && topRef.parent!=window){
    topRef=topRef.parent;
    topRefStr=topRefStr + ".parent";
  }
  if (typeof(win.DIF_mainHandlersAdded)=="undefined" || !win.DIF_mainHandlersAdded){
    with (win){ 
      eval("function OnMouseDownHandler(evt){ if(typeof(evt)=='undefined'){evt=event;}"+topRefStr+".parent.DIF_begindrag(evt, "+topRefStr+") }");
      eval("document.onmousedown=OnMouseDownHandler;");
      eval("function OnMouseUpHandler(evt){ if(typeof(evt)=='undefined'){evt=event;}"+topRefStr+".parent.DIF_enddrag(evt, "+topRefStr+") }");
      eval("document.onmouseup=OnMouseUpHandler;");
      eval("function OnMouseMoveHandler(evt){ if(typeof(evt)=='undefined'){evt=event;}"+topRefStr+".parent.DIF_iframemove(evt, "+topRefStr+") }");
      eval("document.onmousemove=OnMouseMoveHandler;");
      win.DIF_handlersAdded=true;
      win.DIF_mainHandlersAdded=true;
      }
    }
  if (typeof(window.DIF_handlersAdded)!="undefined" || !window.DIF_handlersAdded){
    eval("function OnMouseMoveHandler(evt){ if(typeof(evt)=='undefined'){evt=event;}DIF_mouseMove(evt, window) }");
    eval("document.onmousemove=OnMouseMoveHandler;");
    window.DIF_handlersAdded=true;
    }
  var name=DIF_getIframeId(topRef);
  if (DIF_handles[name]==null){
    DIF_handles[name]=new Array();
    DIF_iframeMouseDownLeft[name]=0;
    DIF_iframeMouseDownTop[name]=0;
    DIF_pageMouseDownLeft[name]=0;
    DIF_pageMouseDownTop[name]=0;
    }
  DIF_handles[name][DIF_handles[name].length]=o;
  }

function DIF_getEventPosition(evt){
  var pos=new Object();
  pos.x=0;
  pos.y=0;
  if (!evt){
    evt=window.event;
    }
  if (typeof(evt.pageX) == 'number'){
    pos.x=evt.pageX;
    pos.y=evt.pageY;
  }
  else {
    pos.x=evt.clientX;
    pos.y=evt.clientY;
    if (!top.opera){
      if ((!window.document.compatMode) || (window.document.compatMode == 'BackCompat')){
        pos.x += window.document.body.scrollLeft;
        pos.y += window.document.body.scrollTop;
      }
      else {
        pos.x += window.document.documentElement.scrollLeft;
        pos.y += window.document.documentElement.scrollTop;
      }
    }
  }
  return pos;
}

function DIF_getIframeId(win){
  var iframes=document.getElementsByTagName("IFRAME");
  for (var i=0; i<iframes.length; i++){
    var o=iframes.item(i);
    var w=null;
    if (o.contentWindow){
      w=o.contentWindow;
      }
    else if (window.frames && window.frames[o.id].window){
      w=window.frames[o.id];
      }
    if (w == win){
      DIF_iframeWindows[o.id]=win;
      DIF_iframeObjects[o.id]=o;
      return o.id; 
      }
    }
  return null;
  }

function DIF_getObjectXY(o){
  var res=new Object();
  res.x=0; res.y=0;
  if (o != null){
    res.x=o.style.left.substring(0,o.style.left.indexOf("px"));
    res.y=o.style.top.substring(0,o.style.top.indexOf("px"));
    }
  return res;
  }

function getSrcElement(e){
  var tgt=e.target;
  while (tgt.nodeType != 1){ tgt=tgt.parentNode;}
  return tgt;
  }

function isHandleClicked(handle, objectClicked){
  if (handle==objectClicked){ return true;}
  while (objectClicked.parentNode != null){
    if (objectClicked==handle){
      return true;
      }
    objectClicked=objectClicked.parentNode;
    }
  return false;
  }
  
function DIF_begindrag(e, win){
  var iframename=DIF_getIframeId(win);
  if (iframename==null){ return;}
  if (DIF_handles[iframename]==null || DIF_handles[iframename].length<1)return;
  var isHandle=false;
  var t=e.srcElement || getSrcElement(e);
  for(var i=0; i<DIF_handles[iframename].length; i++){
    if(isHandleClicked(DIF_handles[iframename][i],t)){
      isHandle=true;
      break;
      }
    }
  if(!isHandle)return false;
  DIF_iframeBeingDragged=iframename;
  if (DIF_raiseSelectedIframe)DIF_iframeObjects[DIF_iframeBeingDragged].style.zIndex=DIF_highestZIndex++;
  DIF_dragging=true;
  var pos=DIF_getEventPosition(e);
  DIF_iframeMouseDownLeft[DIF_iframeBeingDragged]=pos.x;
  DIF_iframeMouseDownTop[DIF_iframeBeingDragged]=pos.y;
  var o=DIF_getObjectXY(DIF_iframeObjects[DIF_iframeBeingDragged]);
  DIF_pageMouseDownLeft[DIF_iframeBeingDragged]=o.x - 0 + pos.x;
  DIF_pageMouseDownTop[DIF_iframeBeingDragged]=o.y -0 + pos.y;
  }

function DIF_enddrag(e){
  DIF_dragging=false;
  DIF_iframeBeingDragged="";
  }

function DIF_mouseMove(e){
  if (DIF_dragging){
    var pos=DIF_getEventPosition(e);
    DIF_drag(pos.x - DIF_pageMouseDownLeft[DIF_iframeBeingDragged] , pos.y - DIF_pageMouseDownTop[DIF_iframeBeingDragged]);
    }
  }

function DIF_iframemove(e){
  if (DIF_dragging){
    var pos=DIF_getEventPosition(e);
    DIF_drag(pos.x - DIF_iframeMouseDownLeft[DIF_iframeBeingDragged] , pos.y - DIF_iframeMouseDownTop[DIF_iframeBeingDragged]);
    }
  }

function DIF_drag(x,y){
  var o=DIF_getObjectXY(DIF_iframeObjects[DIF_iframeBeingDragged]);
  var newPositionX=o.x-0+x;
  var newPositionY=o.y-0+y;
  if (!DIF_allowDragOffScreen){
    if (newPositionX < 0){ newPositionX=0;}
    if (newPositionY < 0){ newPositionY=0;}
    }
  DIF_iframeObjects[DIF_iframeBeingDragged].style.left=newPositionX + "px";
  DIF_iframeObjects[DIF_iframeBeingDragged].style.top =newPositionY + "px";
  DIF_pageMouseDownLeft[DIF_iframeBeingDragged] += x;
  DIF_pageMouseDownTop[DIF_iframeBeingDragged] += y;
  }

var overlay=null;
function findOverlayRef(){
  if( document.layers ){
    return document.layers["overlay"];}
  if( document.getElementById ){
    return document.getElementById("overlay");}
  if( document.all ){
    return document.all["overlay"];}
  if( document["overlay"] ){
    return document["overlay"];}
  return false;
}
function setupOverlay(){
  if((obj=findOverlayRef())){
    overlay=new Object();
    overlay.div=obj;
    overlay.px=document.childNodes?'px':0;
    overlay.style=obj.style?obj.style:obj;
    return true;
  }
  return false;
}
function rewriteOverlayDiv( s ){
  if( typeof( overlay.div.innerHTML )!='undefined' ){
    overlay.div.innerHTML=s;
  } else {
    if( overlay.div.document && overlay.div.document!=window.document ){
      overlay.div.document.open();
      overlay.div.document.write(s);
      overlay.div.document.close();
    }
  }
}

function windowopen(title,src,left,top,tamx,tamy){
  if(!overlay){if(!setupOverlay()) return false;}
  rewriteOverlayDiv("");
  var v=navigator.userAgent.toUpperCase();
  if(1+v.indexOf('MSIE')){var Xadic=10;var Yadic=29;}
  else{var Xadic=18;var Yadic=37;}
  left+=document.body.scrollLeft;top+=document.body.scrollTop;
  var s='<iframe scrolling=no frameborder=0 name=iframePOP ID=iframePOP style=z-index:210;position:absolute;left:'+left+'px;top:'+top+'px;width:'+(tamx+Xadic)+'px;height:'+(tamy+Yadic)+'px src='+ FCLib$.uk("url-popup-iframe") +'?src='+ escape(src)+'&title='+escape(title)+'&tamy='+(tamy+Yadic)+'><\/iframe>';
  rewriteOverlayDiv(s);
  return void(0);
}

function fechaIf(){
  window.parent.parent.document.getElementById("iframePOP").style.visibility='hidden';
  window.parent.document.getElementById("iframeInt").src='ChatVazio.htm?cccfc=1';
}

function moveOverlay(t,l){
  if(!overlay){ if(!setupOverlay()) return false;}
  overlay.style.left=l + overlay.px;
  overlay.style.top=t + overlay.px;
  return false;
}
function sizeOverlay(h,w){
  if(!overlay){ if(!setupOverlay()) return false;}
  if( overlay.style.resizeTo ) overlay.style.resizeTo( w, h );
  overlay.style.width=w + overlay.px;
  overlay.style.pixelWidth=w;
  overlay.style.height=h + overlay.px;
  overlay.style.pixelHeight=h;
  return false;
}

function getRandomNum(lbound,ubound){return(Math.floor(Math.random()*(ubound-lbound))+lbound);}
function getRandomChar(){
  var sChars="0123456789abcdefghijklmnopqrstuvwxyz";
  return sChars.charAt(getRandomNum(0,sChars.length));
}
function getRandomID(pos){
  var rc="";
  rc=rc+getRandomChar();
  for(var idx=1;idx<pos;++idx)rc=rc+getRandomChar();
  return rc;
}

function hideLayerFC(DisappearFlash){
  if(document.getElementById){document.getElementById(DisappearFlash).style.visibility="hidden";}
  else if(document.all){document.all[DisappearFlash].style.visibility="hidden";}
  else if(document.layers){document.layers[DisappearFlash].visibility="hidden";}
}

function FlashSemBorda(Arquivo,Largura,Altura,BGcolor,Base){
  AC_FL_RunContent('codebase','https://download.macromedia.com/pub/shockwave/cabs/flash/swflash.cab#version=6,0,29,0','width',Largura,'height',Altura,'src',Arquivo,'quality','high','pluginspage','https://www.macromedia.com/go/getflashplayer','movie',Arquivo,'wmode','transparent','bgcolor',BGcolor,'base',Base);
}

function AC_AddExtension(src, ext){
  if (src.indexOf('?') != -1)
    return src.replace(/\?/, ext+'?'); 
  else
    return src + ext;
}

function AC_Generateobj(objAttrs,params,embedAttrs){
  if(CodeOnNoObject!="" && (sBrowser=='SAIPAD' || sBrowser=='SAIPHONE'))str=CodeOnNoObject;
  else {
    var sRandomID='f'+getRandomID(7);
    var str = '<object id='+sRandomID+' ';
    for (var i in objAttrs)
      str += i + '="' + objAttrs[i] + '" ';
    str += '>';
    for (var i in params)
      str += '<param name="' + i + '" value="' + params[i] + '" /> ';
    str += '<embed name='+sRandomID+' ';
    for (var i in embedAttrs)
      str += i + '="' + embedAttrs[i] + '" ';
    str += ' >';
    str += '</embed>';
    if(CodeOnNoObject!="" && sBrowser!='FF' && sBrowser!='CH' && sBrowser!='IE' && sBrowser!='SA' && sBrowser!='OP' && sBrowser!='XO')str += '<noobject>'+ CodeOnNoObject +'</noobject>';
    str += '</object>';
  }
  document.write(str);
}

function AC_FL_RunContent(){
  var ret = 
    AC_GetArgs
    (  arguments, ".swf", "movie", "clsid:d27cdb6e-ae6d-11cf-96b8-444553540000"
     , "application/x-shockwave-flash"
    );
  AC_Generateobj(ret.objAttrs, ret.params, ret.embedAttrs);
}

function AC_GetArgs(args, ext, srcParamName, classid, mimeType){
  var ret = new Object();
  ret.embedAttrs = new Object();
  ret.params = new Object();
  ret.objAttrs = new Object();
  for (var i=0; i < args.length; i=i+2){
    var currArg = args[i].toLowerCase();    
    switch (currArg){
      case "classid":
        break;
      case "pluginspage":
        ret.embedAttrs[args[i]] = args[i+1];
        break;
      case "src":
      case "movie":
        if(args[i+1].indexOf('youtube.com')==-1) args[i+1] = AC_AddExtension(args[i+1], ext);
        ret.embedAttrs["src"] = args[i+1];
        ret.params[srcParamName] = args[i+1];
        break;
      case "onafterupdate":
      case "onbeforeupdate":
      case "onblur":
      case "oncellchange":
      case "onclick":
      case "ondblClick":
      case "ondrag":
      case "ondragend":
      case "ondragenter":
      case "ondragleave":
      case "ondragover":
      case "ondrop":
      case "onfinish":
      case "onfocus":
      case "onhelp":
      case "onmousedown":
      case "onmouseup":
      case "onmouseover":
      case "onmousemove":
      case "onmouseout":
      case "onkeypress":
      case "onkeydown":
      case "onkeyup":
      case "onload":
      case "onlosecapture":
      case "onpropertychange":
      case "onreadystatechange":
      case "onrowsdelete":
      case "onrowenter":
      case "onrowexit":
      case "onrowsinserted":
      case "onstart":
      case "onscroll":
      case "onbeforeeditfocus":
      case "onactivate":
      case "onbeforedeactivate":
      case "ondeactivate":
      case "type":
      case "codebase":
        ret.objAttrs[args[i]] = args[i+1];
        break;
      case "width":
      case "height":
      case "align":
      case "vspace": 
      case "hspace":
      case "class":
      case "title":
      case "accesskey":
      case "name":
      case "id":
      case "tabindex":
        ret.embedAttrs[args[i]] = ret.objAttrs[args[i]] = args[i+1];
        break;
      default:
        ret.embedAttrs[args[i]] = ret.params[args[i]] = args[i+1];
    }
  }
  ret.objAttrs["classid"] = classid;
  if (mimeType) ret.embedAttrs["type"] = mimeType;
  return ret;
}

var oDivShowCartOnPage=null;
var iLastCartOnPage=0;

function ShowCartOnPageFC(IDLoja,iErr,sMsg,sCartText,sCheckoutText,este){
  var oPos=getPos(este);
  if(oDivShowCartOnPage==null){
    var oNewElement=document.createElement("div");
    oNewElement.setAttribute("id","DivShowCartOnPage"); 
    oDivShowCartOnPage=document.body.appendChild(oNewElement);
  }
  oDivShowCartOnPage.style.backgroundColor="#dedede";
  oDivShowCartOnPage.style.borderColor="#ffffff";
  oDivShowCartOnPage.style.color="#555555";
  oDivShowCartOnPage.style.border="1px solid #666666";
  oDivShowCartOnPage.style.marginTop="-100px";
  oDivShowCartOnPage.style.marginLeft="-70px";
  oDivShowCartOnPage.style.position="absolute";
  oDivShowCartOnPage.style.zIndex="1";
  oDivShowCartOnPage.style.visibility="visible";
  if(iErr==0)sBackColor="67a54b"; else sBackColor="949494";
  var sHTML="<table id=idTabShowCartOnPageFC width=165 height=100 cellpadding=3 cellspacing=3>";
     sHTML+="<tr><td id=idTDTitShowCartOnPageFC colspan=5 align=center style='background-color:#"+ sBackColor +";color:#ffffff;border-width:1px;border-color:#3b6e22;font-weight:bold;font-size:11px;font-family:verdana;cursor:pointer'>"+ sMsg +"</td></tr>";
     if(iErr==0){
       sHTML+="<tr height=50>";
       sHTML+="<td width=3>&nbsp;</td>";
       sHTML+="<td align=center style=cursor:pointer onclick=window.location.href='"+ FCLib$.uk("url-add-product") +"'><a href='"+ FCLib$.uk("url-add-product") +"' style=color:#444444;text-decoration:none;font-size:11px;>"+ sCartText +"</a></td>";
       sHTML+="<td width=3>&nbsp;</td>";
       sHTML+="<td align=center style=cursor:pointer onclick=window.location.href='"+ FCLib$.uk("url-add-product") +"'><a href='"+ FCLib$.uk("url-add-product") +"' style=color:#444444;text-decoration:none;font-size:11px;>"+ sCheckoutText +"</a></td>";
       sHTML+="<td align=right><img src='/images/cancel_off.png?cccfc=1' hspace=5 style='cursor:pointer' onclick=oDivShowCartOnPage.style.visibility='hidden'></td>";
       sHTML+="</tr>";
     }
     else{
       sHTML+="<tr height=20>";
       sHTML+="<td colspan=5 align=center><img src='/images/cancel_off.png?cccfc=1' hspace=5 style='cursor:pointer' onclick=oDivShowCartOnPage.style.visibility='hidden'></td>";
       sHTML+="</tr>";
     }
     sHTML+="</table>";
  oDivShowCartOnPage.style.top=oPos.y+"px";
  oDivShowCartOnPage.style.left=oPos.x+"px";
  oDivShowCartOnPage.innerHTML=sHTML;
  iLastCartOnPage++;
  setTimeout("if(iLastCartOnPage=="+ iLastCartOnPage +")oDivShowCartOnPage.style.visibility='hidden';",4000);
}


function DocWriteFC(texto){document.getElementById(idDocWriteFC).innerHTML+=texto;}

function ShowXMLPageFC(obj){
  try{
    if(sBrowser=='FF')var sHTMLPage=obj.getElementsByTagName("HTMLPage")[0].textContent;
    else var sHTMLPage=obj.getElementsByTagName("HTMLPage")[0].firstChild.data;
  }
  catch(e){
    document.getElementById(idLoadWaitFC).style.visibility='hidden';
    document.getElementById('idPaginationProdFC').style.visibility='visible';
    document.getElementById('idPageCountFC').style.visibility='visible';
    return;
  }
  var oLoadPoint=document.getElementById(idLoadPointFC);
  if(oLoadPoint){
    if(typeof FuncAutoPagPostload==="function"){
      var sHTMLPageNew=FuncAutoPagPostload(sHTMLPage,iPagProdFC);
      if(sHTMLPageNew && sHTMLPageNew.length>0)sHTMLPage=sHTMLPageNew;else console.log("FuncAutoPagPostload() returned invalid or empty HTML");
    }
    oLoadPoint.innerHTML=sHTMLPage;
    var aScript=oLoadPoint.getElementsByTagName("script");
    if(aScript.length>0){
      var dw=document.write;
      document.write=DocWriteFC;
      var newSpan;
      for(var i=0;i<aScript.length;i++){
        if(aScript[i].type!="application/ld+json"){
          idDocWriteFC="idPag"+ iPagProdFC +"Scr"+ i;
          newSpan=document.createElement("span");
          newSpan.id=idDocWriteFC;
          aScript[i].parentNode.insertBefore(newSpan,aScript[i]);
          if(window.execScript)window.execScript(aScript[i].text);
          else window.eval(aScript[i].text);
        }
      }
      document.write=dw;
    }
    iPagProdFC++;
    if(iPagProdFC<AutoPagProdFC)SetLoadPageFC();
  }
  if(typeof gtag!='undefined'){ 
    var sURL_Analytics=FCLib$.uk("url-prod") +"?"+ QueryProdFC +'&pag='+ iPagProdFC;
    sURL_Analytics=sURL_Analytics.replace("&xml=1","");
    gtag('event', 'page_view', {'send_to': FC$.GA,'page_path':sURL_Analytics});
  }
  else if(typeof ga!=='undefined'){
    var sURL_Analytics=FCLib$.uk("url-prod") +"?"+ QueryProdFC +'&pag='+ iPagProdFC;
    sURL_Analytics=sURL_Analytics.replace("&xml=1","");
    ga('send', 'pageview',sURL_Analytics);
  }
  else if(typeof _gaq!='undefined'){ 
    var sURL_Analytics=FCLib$.uk("url-prod") +"?"+ QueryProdFC +'&pag='+ iPagProdFC;
    sURL_Analytics=sURL_Analytics.replace("&xml=1","");
    _gaq.push(['_trackPageview',sURL_Analytics]);
  }
  if(typeof dataLayerGTM!=='undefined'){
    var sURL_GTM=FCLib$.uk("url-prod") +"?"+ QueryProdFC +'&pag='+ iPagProdFC;
    sURL_GTM=sURL_GTM.replace("&xml=1","");
    dataLayerGTM.push({
      'event': 'VirtualPageview',
      'eventName': 'autoListProducts',
      'eventTitle': document.title +" ("+ iPagProdFC +")",
      'urlPage': sURL_GTM
    });
  }
  try{execAutoPagLazyLoad();}catch(e){}
  try{FuncAutoPagEnd();}catch(e){}
}

function ViewPortWidthFC(){ 
  if(window.innerWidth)return window.innerWidth;
  else return Math.max(document.documentElement.clientWidth,document.body.clientWidth);
} 

function ViewPortHeightFC(){ 
  if(window.innerHeight)return window.innerHeight;
  else return Math.max(document.documentElement.clientHeight,document.body.clientHeight);
} 

function scrollHeightFC(){ 
  if(window.pageYOffset)return window.pageYOffset;
  else return Math.max(document.documentElement.scrollTop,document.body.scrollTop);
} 

function scrollWidthFC(){ 
  if(window.pageXOffset)return window.pageXOffset;
  else return Math.max(document.documentElement.scrollLeft,document.body.scrollLeft);
} 

function IsBelowObj(obj){return(getPos(obj).y-OffsetAutoPagFC<=(ViewPortHeightFC()+scrollHeightFC()));}

function LoadPagePreFC(){
  var oFlag=document.getElementById(idLoadFlagFC);
  if(oFlag){
    if(IsBelowObj(oFlag)){
      window.onscroll=null;
      if(document.getElementById(idLoadPointFC))setTimeout("StartLoadPageFC()",TimeToAutoPagFC);
    }
  }
}

function StartLoadPageFC(){
  var oStartLoad={"bLoadNext":true};
  document.getElementById(idLoadWaitFC).style.visibility='visible';
  if(iPagProdFC==1){
    document.getElementById('idPaginationProdFC').style.visibility='hidden';
    document.getElementById('idPageCountFC').style.visibility='hidden';
  }
  try{FuncAutoPagStart(oStartLoad);}catch(e){}
  if(typeof window.iNextPageButFC!="undefined" && iNextPageButFC>0)fnNextPageButFC(oStartLoad);
  if(oStartLoad.bLoadNext)LoadNextPageFC();
}

function LoadNextPageFC(){
  if(typeof FuncAutoPagPreload==="function")FuncAutoPagPreload(iPagProdFC);
  AjaxExecFC(FCLib$.uk("url-prod"),QueryProdFC +'&pag='+ (iPagProdFC+1),false,ShowXMLPageFC);
}

function fnNextPageButFC(oStartLoad){
  "use strict";
  var IdiomaLoja=FC$.Language,
      XYZ=["Ver mais produtos","Show more products","Mostrar m�s productos","Veja mais produtos","product-list-next-page-button"];
  if(iPagProdFC % iNextPageButFC==0){
    oStartLoad.bLoadNext=false;
    var oLoadWaitFC=document.getElementById(idLoadWaitFC);
    if(oLoadWaitFC){
      if(ImgLoadingFC && ImgLoadingFC.length>0)var sImgLoading="<img src='"+ ImgLoadingFC +"' id=idLoadingNextPageFC"+ iPagProdFC +" class=estLoadingNextPageFC>";
      else var sImgLoading="";
      FCLib$.processLanguageResource(XYZ);
      oLoadWaitFC.innerHTML="<span class=estNextPageContFC><button class=estNextPageButFC onclick='fnNextPageButClickFC(this);'><span class=estTxtNextPageButFC>"+ XYZ[IdiomaLoja] +"</span></button>"+ sImgLoading +"</span>";
    }
  }
}

function fnNextPageButClickFC(este){
  if(ImgLoadingFC && ImgLoadingFC.length>0)document.getElementById("idLoadingNextPageFC"+ iPagProdFC).style.visibility='visible';
  este.setAttribute("disabled","true");
  LoadNextPageFC();
}

function SetLoadPageFC(){
  idLoadFlagFC="idLoadFlagFC"+ iPagProdFC;
  idLoadWaitFC="idLoadWaitFC"+ iPagProdFC;
  idLoadPointFC="idLoadPointFC"+ iPagProdFC;
  window.onscroll=LoadPagePreFC;
}

function ShowImgLoadingFC(este){
  este.onload=null;
  este.src=ImgLoadingFC;
}

function fnFreightSimulation(){
  var sNumCEP=FCLib$.GetCookie("CEP"+FC$.IDLoja);
  if(sNumCEP==null)sNumCEP="";
  var oFreightSimulation=document.getElementById("idFreightSimulationFC");
  if(oFreightSimulation){
    oDivFreightSimulation.style.top=(scrollHeightFC()+((ViewPortHeightFC()-200)/2))+"px";
    oDivFreightSimulation.style.left=(scrollWidthFC()+((ViewPortWidthFC()-400)/2))+"px"; 
    oFreightSimulation.style.display="";
    var oCEPoverlay=document.getElementById('idCEPoverlayFC');
    if(oCEPoverlay)oCEPoverlay.style.display="";
  }
  else{
    var sCEP="";
    sCEP+="<style>";
    sCEP+=".ZipTitType{font-size:11px;color:#555555;font-family:arial,tahoma,verdana;}";
    sCEP+=".ZipName{font-size:11px;color:#555555;font-family:arial,tahoma,verdana;font-weight:bold;}";
    sCEP+=".ZipObsVal{font-size:11px;color:#555555;font-family:arial,tahoma,verdana;}";
    sCEP+=".ZipValue{font-size:12px;color:#333333;font-family:arial,tahoma,verdana;font-weight:bold}";
    sCEP+="</style>";
    sCEP+="<table name=TabFreightSimulation id=idTDFreightSimulationFC width=350 cellspacing=0 cellpadding=0 align=center>";
    sCEP+="  <tr><td class=EstTabPedidoTit style='text-align:center;padding:8px;border-radius: 10px 10px 0px 0px; -moz-border-radius: 10px 10px 0px 0px; -webkit-border-radius: 10px 10px 0px 0px'>Consulte o frete</td></tr>";
    sCEP+="  <tr class=EstTabPedido height=50>";
    sCEP+="    <td align='center'>";
    sCEP+="      <table>";
    sCEP+="        <tr>";
    sCEP+="          <td class='ZipTitType'>Digite seu CEP:</td>";
    sCEP+="          <td><input type='text' id='idZip' size='10' value='"+ sNumCEP +"' maxlength='9' class='InputText'></td>";
    sCEP+="          <td>&nbsp;<input type='button' value='Consultar' id='idBut' class='InputButton' onclick='fnGetShippingValues()'></td>";
    sCEP+="        </tr>";
    sCEP+="      </table>";
    sCEP+="    </td>";
    sCEP+="  </tr>";
    sCEP+="  <tr class=EstTabPedido><td align=center><img src='/images/loading.gif?cccfc=1' vspace=3 style='display:none;' id=ImgLoadingCEP><div id='idShippingValues'></div></td></tr>";
    sCEP+="  <tr><td class=EstTabPedido style='text-align:right;padding:8px;border-radius: 0px 0px 10px 10px; -moz-border-radius: 0px 0px 10px 10px; -webkit-border-radius: 0px 0px 10px 10px'><a href='#na' onclick='fnCloseFreightSimulation();'>Fechar</a></td></tr>";
    sCEP+="</table>";
    var oInsert=document.getElementById("TabInterna");
    if(!oInsert)oInsert=document.getElementById("idFCContent");
    var oNewElement=document.createElement("div");
    oNewElement.setAttribute("id","idFreightSimulationFC"); 
    oDivFreightSimulation=oInsert.parentNode.insertBefore(oNewElement,oInsert);
    oDivFreightSimulation.innerHTML=sCEP;
    oDivFreightSimulation.style.borderRadius='10px';
    oDivFreightSimulation.style.MozBorderRadius='10px';
    oDivFreightSimulation.style.padding='5px';
    oDivFreightSimulation.style.borderColor='#999999';
    oDivFreightSimulation.style.borderStyle='solid';
    oDivFreightSimulation.style.borderWidth='1px';
    oDivFreightSimulation.style.backgroundColor='#FCFCFC';
    oDivFreightSimulation.style.zIndex='11';
    oDivFreightSimulation.style.position='absolute';
    oDivFreightSimulation.style.left=(scrollWidthFC()+((ViewPortWidthFC()-400)/2))+"px"; 
    oDivFreightSimulation.style.top=(scrollHeightFC()+((ViewPortHeightFC()-200)/2))+"px"; 
    oDivFreightSimulation.style.display="";

    var IsOldIE=(sBrowser=='IE' && (Agente.indexOf('MSIE 6')>=0 || Agente.indexOf('MSIE 7')>=0 || Agente.indexOf('MSIE 8')>=0));
    if(!IsOldIE){
      var oNewElement=document.createElement("div");
      oNewElement.setAttribute("id","idCEPoverlayFC"); 
      oDivCEPoverlay=oInsert.parentNode.insertBefore(oNewElement,oInsert);
      oDivCEPoverlay.style.backgroundColor='#000000';
      oDivCEPoverlay.style.zIndex='10';
      oDivCEPoverlay.style.position='fixed';
      oDivCEPoverlay.style.left="0px";
      oDivCEPoverlay.style.top="0px";
      oDivCEPoverlay.style.width="100%";
      oDivCEPoverlay.style.height="100%";
      oDivCEPoverlay.style.opacity=0.4;
      oDivCEPoverlay.onclick=fnCloseFreightSimulation;
    }

  }
}

function fnCloseFreightSimulation(){
  document.getElementById('idFreightSimulationFC').style.display="none";
  var oCEPoverlay=document.getElementById('idCEPoverlayFC');
  if(oCEPoverlay)oCEPoverlay.style.display="none";
}

function fnGetShippingValues(){
  var sCEP=document.getElementById("idZip").value;
  FCLib$.SetCookie("CEP"+FC$.IDLoja,sCEP);
  if(sCEP==""){
    document.getElementById("idShippingValues").innerHTML="<span id=idErrInformCEPFC style=color:#990000;>Informe o CEP</span>";
  }
  else{
    document.getElementById("idShippingValues").innerHTML="";
    document.getElementById("ImgLoadingCEP").style.display="";
    AjaxExecFC(FCLib$.uk("url-xml-shipping-cep"),"cep="+ sCEP,false,fnprocessXMLCEP);
  }
}

function fnprocessXMLCEP(obj){
  var sShipping="";
  var oShippingValues=document.getElementById("idShippingValues");
  var iErr=ReadXMLNode(obj,"err");if(iErr==null)return;
  if(iErr!="0"){
    document.getElementById("ImgLoadingCEP").style.display="none";
    oShippingValues.innerHTML="<span id=idErrXMLCEPFC style=color:#990000;>"+ ReadXMLNode(obj,"msg") +"</span>";
    return;
  }
  oShippingValues.innerHTML="";
  sShipping+="<table border=0 cellpadding=5>";
  var iOpt=ReadXMLNode(obj,"OptQt");
  for(var i=1;i<=iOpt;i++){
    var OptName=ReadXMLNode(obj,"Opt"+ i +"Name");
    var OptValue=ReadXMLNode(obj,"Opt"+ i +"Value");
    var OptImage=ReadXMLNode(obj,"Opt"+ i +"Image");
    if(OptImage==null)sImageFreight="";else sImageFreight="<img src='"+ OptImage +"' id=idZipImageFC>";
    var OptObs=ReadXMLNode(obj,"Opt"+ i +"Obs");
    if(OptObs==null)sOptObs="";else sOptObs=OptObs;
    sValorFrete=ReadXMLNode(obj,"Opt"+ i +"Value");
    if(sValorFrete=="R$ 0,00")sValorFrete="FRETE GR�TIS";
    sShipping+="<tr><td valign=top class='ZipImage'>"+ sImageFreight +"</td><td valign=top><span class='ZipName'>"+ OptName +"</span><br><span class='ZipObsVal'>"+ sOptObs +"</span></td><td>&nbsp; </td><td nowrap valign=top class='ZipValue'>"+ OptValue +"</td></tr>";
  }
  sShipping+="</table>";
  oShippingValues.innerHTML=sShipping;
  oShippingValues.style.display="block";
  document.getElementById("ImgLoadingCEP").style.display="none";
}
